import React, { useState, useEffect } from "react";
import axios from "axios";

function Posts() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newPostContent, setNewPostContent] = useState("");
  const [newPostType, setNewPostType] = useState("");
  const [newpostPrivacy, setNewPostPrivacy] = useState("");
  const [editPostContent, setEditPostContent] = useState("");
  const [editModePostId, setEditModePostId] = useState(null);
  const [imageFile, setImageFile] = useState(null);

  const postTypesOptions = [
    "TEXT",
    "IMAGE",
    "VIDEO",
    "LINK",
    "TEXTVIDEO",
    "TEXTIMAGE",
    "TEXTLINK",
  ];

  const privacyOptions = ["PRIVATE", "PUBLIC", "FRIENDS"];

  const token =
    "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqb2huX2RvZTEyMyIsImlhdCI6MTcxNDc2NzM1MiwiZXhwIjoxNzE0ODUzNzUyfQ.DND8UEDKGymM39sPWuYhJoICMCpgV4E1N4tBM8IATtA";

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:8080/posts", {
          headers: {
            Authorization: "Bearer " + token
          },
        });
        setData(response.data._embedded.postList);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Form submitted");
  
    try {
      let content = newPostContent;
      if (newPostType === "IMAGE" && imageFile) {
        content = await readImageFile(imageFile);
      }
      console.log("Request payload:", {
        post_type: newPostType,
        content: content,
        privacy: newpostPrivacy.toUpperCase(),
      });
  
      const formData = new FormData();
      formData.append("post_type", newPostType);
      formData.append("content", content);
      formData.append("privacy", newpostPrivacy.toUpperCase());
  
      const response = await axios.post(
        "http://localhost:8080/posts/1",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: "Bearer " + token,
          },
        }
      );
  
      setData((prevData) => [...prevData, response.data]);
      setNewPostContent("");
      setImageFile(null); // Reset image file after posting
    } catch (error) {
      console.error("Error creating post:", error);
    }
  };
  

  const readImageFile = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        resolve(event.target.result);
      };
      reader.onerror = (error) => {
        reject(error);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/posts/${id}`, {
        headers: {
          Authorization: "Bearer " + token,
        },
      });
      setData((prevData) => prevData.filter((post) => post.post_ID !== id));
    } catch (error) {
      console.error("Error deleting post:", error);
    }
  };

  const handleUpdate = async (id) => {
    try {
      await axios.put(
        `http://localhost:8080/posts/${id}`,
        {
          content: editPostContent,
          privacy: data.find((post) => post.post_ID === id).privacy,
          post_type: data.find((post) => post.post_ID === id).post_type,
        },
        {
          headers: {
            Authorization: "Bearer " + token,
          },
        }
      );
      setData((prevData) =>
        prevData.map((post) => {
          if (post.post_ID === id) {
            return { ...post, content: editPostContent };
          }
          return post;
        })
      );
      setEditModePostId(null);
    } catch (error) {
      console.error("Error updating post:", error);
    }
  };

  const handleImageDrop = (e) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    setImageFile(droppedFile);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error fetching data: {error.message}</div>;

  return (
    <div>
      <h1>Data from Spring Boot Backend:</h1>
      <form onSubmit={handleSubmit}>
        <select
          value={newPostType}
          onChange={(e) => setNewPostType(e.target.value)}
        >
          <option value="" disabled>
            Select Post Type
          </option>
          {postTypesOptions.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
        {newPostType === "IMAGE" ? (
          <div
            onDrop={handleImageDrop}
            onDragOver={(e) => e.preventDefault()}
            style={{
              width: "100%",
              height: "100px",
              border: "1px solid #ccc",
              borderRadius: "5px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              cursor: "pointer",
            }}
          >
            {imageFile ? (
              <div>
                <img
                  src={URL.createObjectURL(imageFile)}
                  alt="Preview"
                  style={{ maxWidth: "100%", maxHeight: "100%" }}
                />
                <button onClick={() => setImageFile(null)}>Remove</button>
              </div>
            ) : (
              <p>Drop image here or click to select</p>
            )}
          </div>
        ) : (
          <input
            type="text"
            value={newPostContent}
            onChange={(e) => setNewPostContent(e.target.value)}
            placeholder="Enter new post content"
          />
        )}
        <select
          value={newpostPrivacy}
          onChange={(e) => setNewPostPrivacy(e.target.value.toUpperCase())}
        >
          <option value="" disabled>
            Select Privacy
          </option>
          {privacyOptions.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>

        <button type="submit">Add Post</button>
      </form>
      <ul>
        {data.length > 0 &&
          data.map((item) => (
            <li key={item.post_ID}>
              {item.post_type === "IMAGE" ? (
                <img src={item.content} alt="Post" />
              ) : (
                <div>{item.content}</div>
              )}
              <button onClick={() => setEditModePostId(item.post_ID)}>
                Edit
              </button>
              <button onClick={() => handleDelete(item.post_ID)}>Delete</button>
            </li>
          ))}
      </ul>
      {editModePostId && (
        <div>
          <input
            type="text"
            value={editPostContent}
            onChange={(e) => setEditPostContent(e.target.value)}
          />
          <button onClick={() => handleUpdate(editModePostId)}>Update</button>
        </div>
      )}
    </div>
  );
}

export default Posts;
