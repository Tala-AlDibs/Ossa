<h1><em>Project Name: Full Stack Social Media Network Project (Ossa)</em></h1>

<h2>Overview</h2>
The Social Media Application is designed to provide a platform for users to connect, comment on posts, and build friendships with other users. It offers a comprehensive set of features for managing user accounts, creating posts, interacting with content, and more.
<h2>Features</h2>
<ol>
<li><em><h3>User Management</h3></em>
<ul>
  <li>Create, update, retrieve, and delete user accounts</li>
<li>Find users by username or email</li>
<li>Handle authentication and authorization</li>
</ul></li>
  
<li><em><h3>Post Management</h3></em>
<ul>
  <li>Create, retrieve, update, and delete posts</li>
<li>React to posts with various emojis</li>
<li>Bookmark posts for future reference</li>
</ul></li>

<li><em><h3>Comment System</h3></em>
<ul>
  <li>Comment on posts</li>
<l>Like or dislike comments</li>
<li>Reply to comments</li>
</ul>
</li>

<li><em><h3>Friendship Management</h3></em>
<ul>
  <li>Send and accept friend requests</li>
<li>View friend list</li>
<li>Unfriend users</li>
</ul>
</li>

<li><em><h3>Notification</h3></em>
<ul>
  <li>Receive notifications for new friend requests, comments, reactions, etc.</li>
</ul>
</li>

<li><em><h3>Sequrity</h3></em>
<ul>
  <li>Secure user authentication using JWT (JSON Web Tokens)</li>
<li>Role-based access control for different user roles (e.g., regular user, admin)</li>
</ul>
</li>
</ol>

<h2><em>Testing</em></h2>
<ul><li><em>Description:</em> Unit tests are implemented for each controllor using JUnit and Mockito frameworks.</li></ul>

<h2><em>Technologies Used</em></h2>
<ul>
  <li><em>Spring Boot:</em> Backend framework for building RESTful APIs</li>
<li><em>Spring Security:</em> Authentication and authorization framework</li>
<li><em>Spring Data JPA:</em> Persistence layer for interacting with databases</li>
<li><em>Hibernate:</em> ORM (Object-Relational Mapping) framework for mapping Java objects to database tables</li>
<li><em>H2 Database:</em> In-memory database for development and testing</li>
<li><em>JUnit 5:</em> Testing framework for unit and integration tests</li>
<li><em>Mockito:</em> Mocking framework for testing</li>
<li><em>HATEOAS:</em> Hypermedia as the Engine of Application State for RESTful APIs</li>
<li><em>Jackson:</em> JSON serialization/deserialization library</li>
</ul>

<h2><em>Setup Instructions</em></h2>
<ul>
  <li>Clone the repository</li>
<li>Create a Database with the name "ossa"</li>
<li>Uncomment the Loaddatabase class</li>
<li>After you run the project and the tables and dummy data in the loaddatabase is loaded comment the load database again</li>
  <li>sign in the user that was already loaded from the database using this JSON body:
  <ul><li>{<br>
    "username": "john_doe123",<br>
    "password": "password"<br>
}</li></ul></li>
  <li>Add a react to a post and a like to a comment through postman:
  <ul><li>the react:<br>{<br>
  "reactionType": "LOVE"<br>
}
  </li>
  <li>the like on a comment:<br>{ }</li>
  </ul>
  </li>
</ul>
  
<h3><em>Contributors</e></h3>
<h6>Tala Al Dibs</h6>
 <h6>Nour Alhuda Abu Nassar</h6> 
 <h6>Zainab Turshan</h6>
