// package com.project.project;

// import static io.restassured.RestAssured.given;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.Mockito.when;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// import org.junit.jupiter.api.BeforeAll;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
// import com.project.project.Comment.*;
// import com.project.project.Notification.NotificationRepository;
// import com.project.project.Post.Post;
// import com.project.project.Post.PostRepository;
// import com.project.project.Post.PostType;
// import com.project.project.Post.Privacy;
// import com.project.project.User.Gender;
// import com.project.project.User.User;
// import com.project.project.User.UserRepository;

// import io.restassured.http.ContentType;
// import io.restassured.response.Response;

// import java.time.*;
// import java.util.Optional;

// @SpringBootTest
// @AutoConfigureMockMvc
// public class CommentControllerTest {

//     @Autowired
//     private MockMvc mockMvc;

//     @Mock
//     private UserRepository userRepository;

//     @Mock
//     private PostRepository postRepository;

//     @Mock
//     private CommentRepository commentRepository;

//     @Mock
//     private NotificationRepository notificationRepository;

//     @InjectMocks
//     private CommentController commentController;

//     private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

//     private User user = new User("joana_doe", "Joana", "Doe", "joana@example.com", "password", Gender.MALE,
//             LocalDate.of(1990, 1, 1), "Location", "1234567890");

//     private Post post = new Post(PostType.TEXT, "Sample post content", LocalDateTime.now(), user, Privacy.PUBLIC);
//     private Comment comment = new Comment("This is a comment", LocalDateTime.now(), user, post);

//     private static String token;

//     @BeforeAll
//     public static void setup() {
//         // Send sign-in request and extract token

//         Response response = given()
//                 .contentType(ContentType.JSON)
//                 .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
//                 .when()
//                 .post("http://localhost:8080/api/auth/signin")
//                 .then()
//                 .extract()
//                 .response();

//         token = response.jsonPath().getString("accessToken");
//         assertNotNull(token); // Ensure token is not null
//     }

//     @Test
//     void testGetAllComments() throws Exception {
//         this.mockMvc.perform(get("/comments").header("Authorization", "Bearer " + token))
//                 .andExpect(MockMvcResultMatchers.status().isOk());
//     }

//     @Test
//     void testGetCommentById_Successful() throws Exception {
//         comment.setComment_ID(1L);

//         // Mock repository behavior
//         when(commentRepository.findById(anyLong())).thenReturn(Optional.of(comment));
//         mockMvc.perform(get("/comments/{id}", 1L)
//                 .header("Authorization", "Bearer " + token)
//                 .contentType(MediaType.APPLICATION_JSON))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     void testCreateComment_Successful() throws Exception {
//         mockMvc = MockMvcBuilders.standaloneSetup(commentController).build();
//         user.setUser_ID(1L);
//         post.setPost_ID(1L);
//         // Mock repository behavior
//         when(userRepository.findById(user.getUser_ID())).thenReturn(Optional.of(user));
//         when(postRepository.findById(post.getPost_ID())).thenReturn(Optional.of(post));
//         when(commentRepository.save(any(Comment.class))).thenReturn(comment);
//         objectMapper.registerModule(new JavaTimeModule());

//         mockMvc.perform(post("/comments/post/{postId}/user/{userId}", post.getPost_ID(), user.getUser_ID())
//                 .header("Authorization", "Bearer " + token)
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(objectMapper.writeValueAsString(comment)))
//                 .andExpect(status().isCreated());
//     }

//     @Test
//     void testCreateReply_Successful() throws Exception {
//         mockMvc = MockMvcBuilders.standaloneSetup(commentController).build();
//         user.setUser_ID(1L);
//         comment.setComment_ID(1L);

//         Comment replyComment = new Comment("Reply Comment", LocalDateTime.now(), user, post, comment);

//         // Mock repository behavior
//         when(userRepository.findById(anyLong())).thenReturn(Optional.of(user));
//         when(commentRepository.findById(anyLong())).thenReturn(Optional.of(comment));
//         when(commentRepository.save(any(Comment.class))).thenReturn(replyComment);

//         mockMvc.perform(post("/commentsReply/comment/{commentId}/user/{userId}", 1L, 1L)
//                 .header("Authorization", "Bearer " + token)
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(objectMapper.writeValueAsString(replyComment)))
//                 .andExpect(status().isCreated());
//     }

//     @Test
//     void testUpdateComment_Successful() throws Exception {
//         comment.setComment_ID(1L);

//         Comment updatedComment = new Comment("Updated Test Comment", LocalDateTime.now(), user, post, null);

//         // Mock repository behavior
//         when(commentRepository.findById(anyLong())).thenReturn(Optional.of(comment));
//         when(commentRepository.save(any(Comment.class))).thenReturn(updatedComment);

//         mockMvc.perform(put("/comments/{id}", 1L)
//                 .header("Authorization", "Bearer " + token)
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(objectMapper.writeValueAsString(updatedComment)))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     void testDeleteComment_Successful() throws Exception {
//         Comment comment = new Comment("Test Comment", LocalDateTime.now(), user, post, null);
//         comment.setComment_ID(1L);

//         // Mock repository behavior
//         when(commentRepository.findById(anyLong())).thenReturn(Optional.of(comment));

//         mockMvc.perform(delete("/comments/{id}", 5L)
//                 .header("Authorization", "Bearer " + token)
//                 .contentType(MediaType.APPLICATION_JSON))
//                 .andExpect(status().isNoContent());
//     }
// }