// package com.project.project;

// import static io.restassured.RestAssured.given;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// import org.junit.jupiter.api.BeforeAll;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.http.ResponseEntity;
// import org.springframework.jdbc.core.JdbcTemplate;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.ResultActions;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
// import com.project.project.Notification.*;
// import com.project.project.User.*;
// import com.project.project.Post.*;
// import com.project.project.React.*;

// import io.restassured.http.ContentType;
// import io.restassured.response.Response;

// import java.time.*;
// import java.util.*;

// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.Mockito.*;

// @SuppressWarnings("all")
// @SpringBootTest
// @AutoConfigureMockMvc
// public class ReactControllerTest {
//         @Autowired
//         private MockMvc mockMvc;

//         @Mock
//         private UserRepository userRepository;

//         @Mock
//         private PostRepository postRepository;

//         @Mock
//         private ReactRepository reactRepository;

//         @Mock
//         private NotificationRepository notificationRepository;

//         @InjectMocks
//         private ReactController reactController;

//         @InjectMocks
//         private UserController userController;

//         @Autowired
//         private JdbcTemplate jdbcTemplate = new JdbcTemplate();

//         private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

//         private User user = new User("joana_doe", "Joana", "Doe", "joana@example.com", "password", Gender.MALE,
//                         LocalDate.of(1990, 1, 1), "Location", "1234567890");
//         private Post post = new Post(PostType.TEXT, "Sample post content", LocalDateTime.now(), user, Privacy.PUBLIC);
//         private React react = new React(new ReactID(user.getUser_ID(), post.getPost_ID()), ReactionType.ANGRY,
//                         LocalDateTime.of(2024, 3, 30, 5, 30), user, post);

//         private static String token;

//         @BeforeAll
//         public static void setup() {
//                 // Send sign-in request and extract token

//                 Response response = given()
//                                 .contentType(ContentType.JSON)
//                                 .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
//                                 .when()
//                                 .post("http://localhost:8080/api/auth/signin")
//                                 .then()
//                                 .extract()
//                                 .response();

//                 token = response.jsonPath().getString("accessToken");
//                 assertNotNull(token); // Ensure token is not null

//         }

//         @Test
//         void testGetAllPosts() throws Exception {

//                 this.mockMvc.perform(get("/reacts").header("Authorization", "Bearer " + token))
//                                 .andExpect(MockMvcResultMatchers.status().isOk());
//         }

//         @Test
//         public void testNewReact() throws Exception {
//                 objectMapper.registerModule(new JavaTimeModule());
//                 mockMvc = MockMvcBuilders.standaloneSetup(reactController).build();
//                 // Mock user and post
//                 Long postId = 1L;
//                 Long userId = 1L;
//                 ReactID reactId = new ReactID(userId, postId);
//                 post.setPost_ID(postId);
//                 user.setUser_ID(userId);
//                 react.setReaction_ID(reactId);

//                 // Mock optional user and post
//                 Optional<User> optionalUser = Optional.of(user);
//                 Optional<Post> optionalPost = Optional.of(post);

//                 // Mock the findById method of the user repository
//                 when(userRepository.findById(user.getUser_ID())).thenReturn(optionalUser);

//                 // Mock the findById method of the post repository
//                 when(postRepository.findById(post.getPost_ID())).thenReturn(optionalPost);

//                 // Mock the save method of the repository
//                 when(reactRepository.save(react)).thenReturn(react);
//                 ResponseEntity<React> responseEntity = reactController.newReact(react, post.getPost_ID(),
//                                 user.getUser_ID());
//                 // Verify that the save method is called
//                 verify(reactRepository, times(1)).save(react);

//                 // Create a JSON representation of the React object
//                 String reactJson = "{\"reaction_ID\": {\"userId\": " + user.getUser_ID() + ", \"postId\": "
//                                 + post.getPost_ID()
//                                 + "}, " +
//                                 "\"reactionType\": \"ANGRY\", \"timestamp\": \"2024-03-30T05:30:00\"}";

//                 // Perform the POST request
//                 mockMvc.perform(MockMvcRequestBuilders
//                                 .post("/reacts/post/{postId}/user/{userId}", post.getPost_ID(), user.getUser_ID())
//                                 .header("Authorization", "Bearer " + token)
//                                 .contentType(MediaType.APPLICATION_JSON)
//                                 .content(reactJson)) // Send the JSON representation of the React object
//                                 .andExpect(status().isCreated())
//                                 .andExpect(jsonPath("$.errors").doesNotExist()); // Expect no validation errors

//         }

//         @Test
//         public void testGetReactsOnPost() throws Exception {
//                 // Mock React objects
//                 React react1 = new React(new ReactID(1L, 1L), ReactionType.LIKE, LocalDateTime.now(), user, post);
//                 React react2 = new React(new ReactID(2L, 1L), ReactionType.LOVE, LocalDateTime.now(), user, post);
//                 List<React> reacts = Arrays.asList(react1, react2);
//                 post.setPost_ID(1L);

//                 // Mock the findAll method of the repository to return the list of Reacts
//                 when(reactRepository.findAll()).thenReturn(reacts);

//                 // Perform the GET request
//                 this.mockMvc.perform(get("/reacts/post/{postId}", post.getPost_ID())
//                                 .header("Authorization", "Bearer " + token))
//                                 .andExpect(MockMvcResultMatchers.status().isOk()); // Assuming this is the relation name
//                                                                                    // for all reacts
//         }

//         @Test
//         public void testGetReactsByUser() throws Exception {
//                 // Mock React objects
//                 React react1 = new React(new ReactID(1L, 1L), ReactionType.LIKE, LocalDateTime.now(), user, post);
//                 React react2 = new React(new ReactID(2L, 1L), ReactionType.LOVE, LocalDateTime.now(), user, post);
//                 List<React> reacts = Arrays.asList(react1, react2);
//                 user.setUser_ID(1L);

//                 // Mock the findAll method of the repository to return the list of Reacts
//                 when(reactRepository.findAll()).thenReturn(reacts);

//                 // Perform the GET request
//                 this.mockMvc.perform(get("/reacts/user/{userId}", user.getUser_ID())
//                                 .header("Authorization", "Bearer " + token))
//                                 .andExpect(MockMvcResultMatchers.status().isOk()); // Assuming this is the relation name
//                                                                                    // for all reacts
//         }

//         @Test
//         void testGetsOneReact() throws Exception {
//                 mockMvc = MockMvcBuilders.standaloneSetup(reactController).build();

//                 // Create sample data
//                 Long postId = 1L;
//                 Long userId = 1L;
//                 ReactID reactId = new ReactID(userId, postId);
//                 post.setPost_ID(postId);
//                 user.setUser_ID(userId);
//                 react.setReaction_ID(reactId);

//                 when(reactRepository.findById(new ReactID(1L, 1L))).thenReturn(Optional.of(react));
//                 final ResultActions result = mockMvc
//                                 .perform(get("/reacts/post/{postId}/user/{userId}", 1L, 1L).header("Authorization",
//                                                 "Bearer " + token));
//                 result.andExpect(status().isOk());
//         }

//         @Test
//         void testReplaceReactSuccessful() throws Exception {
//                 objectMapper.registerModule(new JavaTimeModule());
//                 mockMvc = MockMvcBuilders.standaloneSetup(reactController).build();

//                 // Create sample data
//                 Long postId = 1L;
//                 Long userId = 1L;
//                 ReactID reactId = new ReactID(userId, postId);
//                 post.setPost_ID(postId);
//                 user.setUser_ID(userId);
//                 react.setReaction_ID(reactId);

//                 when(this.reactRepository.findById(any())).thenReturn(Optional.of(react));
//                 when(this.reactRepository.save(any())).thenReturn(react);

//                 // Mock optional user and post
//                 Optional<User> optionalUser = Optional.of(user);
//                 Optional<Post> optionalPost = Optional.of(post);

//                 // Mock the findById method of the user repository
//                 when(userRepository.findById(user.getUser_ID())).thenReturn(optionalUser);

//                 // Mock the findById method of the post repository
//                 when(postRepository.findById(post.getPost_ID())).thenReturn(optionalPost);

//                 // Perform the PUT request
//                 mockMvc.perform(put("/reacts/post/{postId}/user/{userId}", postId.toString(), userId.toString())
//                                 .header("Authorization", "Bearer " + token)
//                                 .contentType(MediaType.APPLICATION_JSON)
//                                 .content(objectMapper.writeValueAsString(react)))
//                                 .andExpect(status().isOk());
//         }

//         @Test
//         public void testDeleteReact_Successful() throws Exception {
//                 Long postId = 1L;
//                 Long userId = 1L;
//                 ReactID reactId = new ReactID(userId, postId);
//                 post.setPost_ID(postId);
//                 user.setUser_ID(userId);
//                 react.setReaction_ID(reactId);

//                 when(reactRepository.findById(reactId)).thenReturn(Optional.of(react));
//                 when(reactRepository.findById(reactId)).thenReturn(Optional.of(react));
//                 // when(userRepository.existsById(userId)).thenReturn(true);

//                 // Perform DELETE request
//                 mockMvc.perform(
//                                 delete("/reacts/post/{postId}/user/{userId}", postId.toString(), userId.toString())
//                                                 .header("Authorization", "Bearer " + token)
//                                                 .contentType(MediaType.APPLICATION_JSON))
//                                 .andExpect(status().isOk()); // Expecting 204 status code
//                 this.mockMvc
//                                 .perform(get("/reacts/post/{postId}/user/{userId}", postId.toString(),
//                                                 userId.toString()).header("Authorization", "Bearer " + token))
//                                 .andExpect(status().isNotFound());
//         }

// }
