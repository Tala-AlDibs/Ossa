package com.project.project;

import static io.restassured.RestAssured.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.project.project.Notification.Notification;
import com.project.project.Notification.NotificationController;
import com.project.project.Notification.NotificationRepository;
import com.project.project.Notification.NotificationType;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

@SuppressWarnings("all")
@SpringBootTest
@AutoConfigureMockMvc
class NotificationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private NotificationController notificationController;

    private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    private Notification notification = new Notification(1L, LocalDateTime.now(), "This is a sample notification",
            NotificationType.COMMENT);

    private static String token;

    @BeforeAll
    public static void setup() {
        // Send sign-in request and extract token

        Response response = given().contentType(ContentType.JSON)
                .body("{\"username\":\"john_doe123\",\"password\":\"password\"}").when()
                .post("http://localhost:8080/api/auth/signin").then().extract().response();

        token = response.jsonPath().getString("accessToken");
        assertNotNull(token); // Ensure token is not null

    }
    // Test case for retrieving all notifications

    @Test
    void testGetAllNotifications() throws Exception {
        mockMvc.perform(get("/notifications")
                .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
    }

    @Test
    public void testNewNotification_Successful() throws Exception {
        // Create a sample notification to be saved
        Notification newNotification = new Notification();
        newNotification.setContent("Test notification");

        // Mock the repository's save method to return the saved notification
        when(notificationRepository.save(newNotification)).thenReturn(newNotification);

        // Perform POST request to create a new notification
        mockMvc.perform(post("/notifications")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"content\":\"Test notification\"}"))
                .andExpect(status().isCreated()); // Expecting HTTP 201 Created
    }

    // Test case for retrieving a notification by ID
    @Test
    void testGetNotificationById_Successful() throws Exception {
        // Arrange

        notification.setNotification_ID(1L);
        // Mock the behavior of findById() to return the notification when called with
        // anyLong()
        when(notificationRepository.findById(anyLong())).thenReturn(Optional.of(notification));

        // Act and Assert
        mockMvc.perform(get("/notifications/{id}", 1L)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void testDeleteNotification_NotFound() throws Exception {
        // Define a non-existent notification ID
        Long notificationId = 1L;

        // Mock the behavior of findById() to return an empty Optional (notification not
        // found)
        when(notificationRepository.findById(notificationId)).thenReturn(Optional.empty());

        // Perform DELETE request
        mockMvc.perform(MockMvcRequestBuilders.delete("/notifications/{id}", notificationId)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound()); // Expecting status code 404
    }

}