package com.project.project;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.project.project.Notification.NotificationRepository;
import com.project.project.User.*;
import com.project.project.Home.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.time.LocalDate;

import static org.mockito.Mockito.*;

@SuppressWarnings("all")
@SpringBootTest
@AutoConfigureMockMvc
public class HomeControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private UserRepository userRepository;

    @Mock
    private HomeRepository homeRepository;

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private HomeController homeController;

    @Autowired
    private JdbcTemplate jdbcTemplate = new JdbcTemplate();

    private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    private User newUser = new User("john_doe", "John", "Doe", "john@example.com", "password", Gender.MALE,
            LocalDate.of(1990, 1, 1), "Location", "1234567890");
    private Home home = new Home(newUser);
    private static String token;

    @BeforeAll
    public static void setup() {
        // Send sign-in request and extract token

        Response response = given()
                .contentType(ContentType.JSON)
                .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
                .when()
                .post("http://localhost:8080/api/auth/signin")
                .then()
                .extract()
                .response();

        token = response.jsonPath().getString("accessToken");
        assertNotNull(token); // Ensure token is not null
    }

    @Test
    void testGetAllHomes() throws Exception {

        this.mockMvc.perform(get("/homes").header("Authorization", "Bearer " + token))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void testNewHome_Successful() throws Exception {

        // Set up mockMvc
        mockMvc = MockMvcBuilders.standaloneSetup(homeController).build();

        // Arrange
        when(homeRepository.save(home)).thenReturn(home);

        // Act
        ResponseEntity<Home> responseEntity = homeController.createHome(home);

        // Assert
        // Verify repository method call
        verify(homeRepository, times(1)).save(home);

        // Perform mockMvc request
        mockMvc.perform(post("/homes")
                .header("Authorization", "Bearer " + token)
                .content(
                        "{\"username\":\"john_doe\",\"first_name\":\"John\",\"last_name\":\"Doe\",\"email\":\"john@example.com\",\"password\":\"password\",\"gender\":\"MALE\",\"date_of_birth\":\"1990-01-01\",\"location\":\"Location\",\"phone_number\":\"1234567890\"}")
                .contentType("application/json"))
                .andExpect(status().isCreated());
    }

    @Test
    void testGetHomeById_Successful() throws Exception {
        home.setHome_ID(1L);
        // Act and Assert
        this.mockMvc.perform(get("/homes/" + home.getHome_ID().toString())
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

}
