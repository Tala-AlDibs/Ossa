package com.project.project;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import com.project.project.Profile.*;
import com.project.project.User.*;
import com.project.project.payload.request.*;
import com.project.project.security.services.UserDetailsImpl;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import com.project.project.security.jwt.JwtUtils;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

@SuppressWarnings("all")
@SpringBootTest
@AutoConfigureMockMvc
public class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthenticationManager authenticationManager;

    @MockBean
    private JwtUtils jwtUtils;

    private static String token;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    PasswordEncoder encoder;

    @BeforeAll
    public static void setup() {
        // Send sign-in request and extract token

        Response response = given()
                .contentType(ContentType.JSON)
                .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
                .when()
                .post("http://localhost:8080/api/auth/signin")
                .then()
                .extract()
                .response();

        token = response.jsonPath().getString("accessToken");
        assertNotNull(token); // Ensure token is not null
    }

    @Test
    void authenticateUser_ReturnsToken() throws Exception {

        Authentication authentication = Mockito.mock(Authentication.class);
        UserDetailsImpl userDetails = Mockito.mock(UserDetailsImpl.class);

        when(authenticationManager.authenticate(any())).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(userDetails);
        when(jwtUtils.generateJwtToken(any())).thenReturn(token);

        // Act
        ResultActions result = mockMvc.perform(post("/api/auth/signin")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{ \"username\": \"username\", \"password\": \"password\" }"));

        // Assert
        result.andExpect(status().isOk());
    }

    @Test
    void registerUser_Successful() throws Exception {
        // Arrange
        UserRepository userRepository = mock(UserRepository.class); // Mock UserRepository
        PasswordEncoder encoder = mock(PasswordEncoder.class); // Mock PasswordEncoder

        // Create a user and signup request
        User user = new User("username", "Johnathan", "Doe", "johnathan@example.com", "password",
                Gender.MALE, LocalDate.parse("1990-01-01"), "Location", "1234567890");

        // Create a Profile object
        Profile profile = new Profile("bio", "profile_picture", user);

        // Create a SignupRequest object with the initialized Profile object
        SignupRequest signupRequest = new SignupRequest(user.getUsername(), user.getFirst_name(), user.getLast_name(),
                user.getEmail(), user.getPassword(),
                user.getGender(), user.getDate_of_birth(), user.getLocation(), user.getPhone_number(), profile);

        // Stub the method invocations on userRepository
        when(userRepository.existsByUsername(signupRequest.getUsername())).thenReturn(false);
        when(userRepository.existsByEmail(signupRequest.getEmail())).thenReturn(false);
        when(encoder.encode(signupRequest.getPassword())).thenReturn("encodedPassword");

        // Act
        ResultActions result = mockMvc.perform(post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                        "{\"username\":\"username\",\"first_name\":\"Johnathan\",\"last_name\":\"Doe\",\"email\":\"johnathan@example.com\",\"password\":\"password\",\"gender\":\"MALE\",\"date_of_birth\":\"1990-01-01\",\"location\":\"Location\",\"phone_number\":\"1234567890\",\"profile\":{\"bio\":\"bio\",\"profile_picture\":\"profile_picture\"}}"));

        // Assert
        result.andExpect(status().isOk());
    }

    @Test
    void registerUser_UsernameAlreadyExists() throws Exception {
        UserRepository userRepository = mock(UserRepository.class); // Mock UserRepository
        PasswordEncoder encoder = mock(PasswordEncoder.class); // Mock PasswordEncoder
        // Arrange
        User user = new User("username", "Johnathan", "Doe", "johnathan@example.com", "password",
                Gender.MALE, LocalDate.parse("1990-01-01"), "Location", "1234567890");

        // Create a Profile object
        Profile profile = new Profile("bio", "profile_picture", user);

        SignupRequest signupRequest = new SignupRequest(user.getUsername(), user.getFirst_name(), user.getLast_name(),
                user.getEmail(), user.getPassword(),
                user.getGender(), user.getDate_of_birth(), user.getLocation(), user.getPhone_number(),
                new Profile("bio", "profile_picture", user));
        when(userRepository.existsByUsername(signupRequest.getUsername())).thenReturn(false);
        // Act
        ResultActions result = mockMvc.perform(post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                        "{\"username\":\"username\",\"first_name\":\"Johnathan\",\"last_name\":\"Doe\",\"email\":\"johathann@example.com\",\"password\":\"password\",\"gender\":\"MALE\",\"date_of_birth\":\"1990-01-01\",\"location\":\"Location\",\"phone_number\":\"1234567890\"}"));

        // Assert
        result.andExpect(status().isBadRequest());
    }

    @Test
    void registerUser_EmailAlreadyExists() throws Exception {
        UserRepository userRepository = mock(UserRepository.class); // Mock UserRepository
        PasswordEncoder encoder = mock(PasswordEncoder.class); // Mock PasswordEncoder
        User user = new User("username", "Johnathan", "Doe", "johnathan@example.com", "password",
                Gender.MALE, LocalDate.parse("1990-01-01"), "Location", "1234567890");

        SignupRequest signupRequest = new SignupRequest(user.getUsername(), user.getFirst_name(), user.getLast_name(),
                user.getEmail(), user.getPassword(),
                user.getGender(), user.getDate_of_birth(), user.getLocation(), user.getPhone_number(),
                new Profile("bio", "profile_picture", user));
        when(userRepository.existsByUsername(signupRequest.getUsername())).thenReturn(false);
        when(userRepository.existsByEmail(signupRequest.getEmail())).thenReturn(true);

        // Act
        ResultActions result = mockMvc.perform(post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                        "{\"username\":\"username\",\"first_name\":\"John\",\"last_name\":\"Doe\",\"email\":\"john@example.com\",\"password\":\"password\",\"gender\":\"MALE\",\"date_of_birth\":\"1990-01-01\",\"location\":\"Location\",\"phone_number\":\"1234567890\"}"));

        // Assert
        result.andExpect(status().isBadRequest());
    }
}
