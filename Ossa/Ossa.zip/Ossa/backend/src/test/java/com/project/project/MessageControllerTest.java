package com.project.project;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.project.project.Messages.*;
import com.project.project.Notification.NotificationRepository;
import com.project.project.User.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

@SpringBootTest
@AutoConfigureMockMvc
public class MessageControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private UserRepository userRepository;

    @Mock
    private MessageRepository messageRepository;

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private MessageController messageController;

    private ObjectMapper objectMapper = new ObjectMapper();

    private static String token;

    private User sender = new User("sender_username", "Sender", "User", "sender@example.com", "password", Gender.MALE,
            LocalDate.of(1990, 1, 1), "Location", "1234567890");
    private User recipient = new User("recipient_username", "Recipient", "User", "recipient@example.com", "password",
            Gender.FEMALE,
            LocalDate.of(1995, 5, 15), "Location", "9876543210");
    private Message message = new Message(sender, recipient, "Sample message content", LocalDateTime.now(),
            MessageStatus.undelivered);

    @BeforeAll
    public static void setup() {
        // Send sign-in request and extract token

        Response response = given()
                .contentType(ContentType.JSON)
                .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
                .when()
                .post("http://localhost:8080/api/auth/signin")
                .then()
                .extract()
                .response();

        token = response.jsonPath().getString("accessToken");
        assertNotNull(token); // Ensure token is not null
    }

    @Test
    void testGetAllMessages() throws Exception {
        this.mockMvc.perform(get("/messages").header("Authorization", "Bearer " + token))
                .andExpect(MockMvcResultMatchers.status().isOk());

    }

    @Test
    void testCreateMessage_Successful() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(messageController).build();

        sender.setUser_ID(1L);
        recipient.setUser_ID(2L);

        // Mock repository behavior
        when(userRepository.findById(sender.getUser_ID())).thenReturn(Optional.of(sender));
        when(userRepository.findById(recipient.getUser_ID())).thenReturn(Optional.of(recipient));
        when(messageRepository.save(any(Message.class))).thenReturn(message);
        objectMapper.registerModule(new JavaTimeModule());

        // Perform POST request
        mockMvc.perform(post("/messages/{senderId}/{receiverId}", sender.getUser_ID(), recipient.getUser_ID())
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(message)))
                .andExpect(status().isCreated());
    }

    @Test
    void testGetMessageById_Successful() throws Exception {
        Long messageId = 2L;
        message.setId(messageId);
        // Act and Assert
        this.mockMvc.perform(get("/messages/{id}", messageId)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void testUpdateMessage_Successful() throws Exception {
        message.setId(1L);
        Message updatedMessage = new Message(sender, recipient, "Updated message content", LocalDateTime.now(),
                MessageStatus.delivered);
        // Mock the repository's behavior
        when(messageRepository.findById(any())).thenReturn(Optional.of(message));
        when(messageRepository.save(any())).thenReturn(updatedMessage);
        objectMapper.registerModule(new JavaTimeModule());

        this.mockMvc.perform(put("/messages/" + message.getId())
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedMessage)).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.content").value(updatedMessage.getContent()));
    }

    @Test
    public void testDeleteMessage_Successful() throws Exception {
        Long messageId = 1L;
        message.setId(messageId);
        when(messageRepository.findById(messageId)).thenReturn(Optional.of(message));

        // Perform DELETE request
        mockMvc.perform(
                delete("/messages/{id}", message.getId().toString()).header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent()); // Expecting 204 status code
        this.mockMvc
                .perform(get("/messages/" + message.getId().toString()).header("Authorization", "Bearer " + token))
                .andExpect(status().isNotFound());
    }

}