package com.project.project;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.project.project.Notification.NotificationRepository;
import com.project.project.User.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.time.LocalDate;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SuppressWarnings("all")
@SpringBootTest
@AutoConfigureMockMvc
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private UserRepository userRepository;

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private UserController userController;

    @Autowired
    private JdbcTemplate jdbcTemplate = new JdbcTemplate();

    private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    private User newUser = new User("john_doe", "John", "Doe", "john@example.com", "password", Gender.MALE,
            LocalDate.of(1990, 1, 1), "Location", "1234567890");
    private User newUserf = new User("Sara_lane", "Sara", "Lane", "sara@example.com", "password", Gender.FEMALE,
            LocalDate.of(1990, 1, 1), "Location", "1234567890");
    // private final static String token =
    // "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJKb2huXzEyMyIsImlhdCI6MTcxMTUzNTExMCwiZXhwIjoxNzExNjIxNTEwfQ.xSsnJPacpWn2X6AL-zPHWoGKNhDagJbxg2DAwFAVWJE";
    private static String token;

    @BeforeAll
    public static void setup() {
        // Send sign-in request and extract token

        Response response = given()
                .contentType(ContentType.JSON)
                .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
                .when()
                .post("http://localhost:8080/api/auth/signin")
                .then()
                .extract()
                .response();

        token = response.jsonPath().getString("accessToken");
        assertNotNull(token); // Ensure token is not null
    }

    @Test
    void testGetAllUsers() throws Exception {

        this.mockMvc.perform(get("/users").header("Authorization", "Bearer " + token))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void testNewUser_Successful() throws Exception {

        // Set up mockMvc
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();

        // Arrange
        when(userRepository.save(newUser)).thenReturn(newUser);

        // Act
        ResponseEntity<User> responseEntity = userController.newUser(newUser);

        // Assert
        // Verify repository method call
        verify(userRepository, times(1)).save(newUser);

        // Perform mockMvc request
        mockMvc.perform(post("/users")
                .header("Authorization", "Bearer " + token)
                .content(
                        "{\"username\":\"john_doe\",\"first_name\":\"John\",\"last_name\":\"Doe\",\"email\":\"john@example.com\",\"password\":\"password\",\"gender\":\"MALE\",\"date_of_birth\":\"1990-01-01\",\"location\":\"Location\",\"phone_number\":\"1234567890\"}")
                .contentType("application/json"))
                .andExpect(status().isCreated());
    }

    @Test
    void testCreateFriendship_Successful() throws Exception {
        // Arrange: Create users and verify they were successfully added
        ResponseEntity<User> responseEntity1 = userController.newUser(newUser);
        ResponseEntity<User> responseEntity2 = userController.newUser(newUserf);
        verify(userRepository, times(1)).save(newUser);
        verify(userRepository, times(1)).save(newUserf);

        // Get the IDs of the newly created users
        Long user1Id = newUser.getUser_ID();
        Long user2Id = newUserf.getUser_ID();

        // Stub the UserRepository to return the users when findById is called with
        // their respective IDs
        when(userRepository.findById(user1Id)).thenReturn(Optional.of(newUser));
        when(userRepository.findById(user2Id)).thenReturn(Optional.of(newUserf));

        // Act: Attempt to create friendship between the users
        ResponseEntity<String> responseEntity = userController.createFriendship(user1Id, user2Id);

        // Assert: Verify that the response is as expected
        assertEquals(ResponseEntity.ok("Friendship created successfully"), responseEntity);
    }

    @Test
    void testDeleteFriendship_Successful() {
        // Arrange: Create users and establish friendship
        ResponseEntity<User> responseEntity1 = userController.newUser(newUser);
        ResponseEntity<User> responseEntity2 = userController.newUser(newUserf);
        verify(userRepository, times(1)).save(newUser);
        verify(userRepository, times(1)).save(newUserf);

        // Get the IDs of the newly created users
        Long user1Id = newUser.getUser_ID();
        Long user2Id = newUserf.getUser_ID();

        // Stub the UserRepository to return the users when findById is called with
        // their respective IDs
        when(userRepository.findById(user1Id)).thenReturn(Optional.of(newUser));
        when(userRepository.findById(user2Id)).thenReturn(Optional.of(newUserf));
        ResponseEntity<String> responseEntityf = userController.createFriendship(user1Id, user2Id);

        // Act: Delete the friendship
        ResponseEntity<String> responseEntity = userController.deleteFriendship(user1Id, user2Id);

        // Assert: Verify that the friendship is deleted successfully
        assertEquals(ResponseEntity.ok("Friendship deleted successfully"), responseEntity);
        assertFalse(newUser.getFriends().contains(newUserf));
        assertFalse(newUserf.getFriends().contains(newUser));
    }

    @Test
    void testGetUserById_Successful() throws Exception {
        newUser.setUser_ID(1L);
        // Act and Assert
        this.mockMvc.perform(get("/users/" + newUser.getUser_ID().toString())
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void testReplaceUserSuccessful() throws Exception {
        objectMapper.registerModule(new JavaTimeModule());
        // Mock the repository's behavior
        when(this.userRepository.findById(any())).thenReturn(Optional.of(newUserf));
        when(this.userRepository.save(any())).thenReturn(newUserf);
        newUserf.setUser_ID(10L);

        this.mockMvc.perform(put("/users/" + newUserf.getUser_ID())
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(newUserf)).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.username").value(newUserf.getUsername()));
    }

    @Test
    public void testDeleteUser_Successful() throws Exception {
        Long userId = 7L;
        newUser.setUser_ID(userId);
        Long user1Id = newUser.getUser_ID();
        when(userRepository.findById(user1Id)).thenReturn(Optional.of(newUser));

        // Perform DELETE request
        mockMvc.perform(
                delete("/users/{id}", newUser.getUser_ID().toString()).header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
        this.mockMvc
                .perform(get("/users/" + newUser.getUser_ID().toString()).header("Authorization", "Bearer " + token))
                .andExpect(status().isNotFound());
    }

}
