package com.project.project;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.project.project.Notification.NotificationRepository;
import com.project.project.Profile.*;
import com.project.project.User.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.time.LocalDate;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SuppressWarnings("all")
@SpringBootTest
@AutoConfigureMockMvc
public class ProfileControllerTest {
        @Autowired
        private MockMvc mockMvc;

        @Mock
        private UserRepository userRepository;

        @Mock
        private ProfileRepository profileRepository;

        @Mock
        private NotificationRepository notificationRepository;

        @InjectMocks
        private ProfileController profileController;

        @Autowired
        private JdbcTemplate jdbcTemplate = new JdbcTemplate();

        private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

        private User newUser = new User("john_doe", "John", "Doe", "john@example.com", "password", Gender.MALE,
                        LocalDate.of(1990, 1, 1), "Location", "1234567890");

        private Profile profile = new Profile("for test", "profile.jpg", newUser);

        public ProfileControllerTest() {
        }

        private static String token;

        @BeforeAll
        public static void setup() {
                // Send sign-in request and extract token

                Response response = given()
                                .contentType(ContentType.JSON)
                                .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
                                .when()
                                .post("http://localhost:8080/api/auth/signin")
                                .then()
                                .extract()
                                .response();

                token = response.jsonPath().getString("accessToken");
                assertNotNull(token); // Ensure token is not null
        }

        @Test
        void testGetAllProfiles() throws Exception {

                this.mockMvc.perform(get("/profiles").header("Authorization", "Bearer " + token))
                                .andExpect(MockMvcResultMatchers.status().isOk());
        }

        @Test
        void testNewProfile_Successful() throws Exception {
                // Set up mockMvc
                mockMvc = MockMvcBuilders.standaloneSetup(profileController).build();

                // Create a new profile
                Profile profile = new Profile("Bio", "ProfilePicture", newUser);

                // Arrange
                when(profileRepository.save(profile)).thenReturn(profile);

                // Perform mockMvc request
                mockMvc.perform(post("/profiles").header("Authorization", "Bearer " + token)
                                .content(
                                                "{\"bio\":\"Bio\",\"profile_picture\":\"ProfilePicture\",\"first_name\":\"John\",\"last_name\":\"Doe\",\"email\":\"john@example.com\",\"password\":\"password\",\"gender\":\"MALE\",\"date_of_birth\":\"1990-01-01\",\"location\":\"Location\",\"phone_number\":\"1234567890\"}")
                                .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
        }

        @Test
        void testGetProfileById_Successful() throws Exception {
                Long profileId = 1L;
                profile.setProfile_ID(profileId);
                when(profileRepository.findById(profileId)).thenReturn(Optional.of(profile));

                mockMvc.perform(get("/profiles/{id}", profileId)
                                .header("Authorization", "Bearer " + token)
                                .contentType(MediaType.APPLICATION_JSON))
                                .andExpect(status().isOk());

        }

        @Test
        void testReplaceProfile_Successful() throws Exception {
                mockMvc = MockMvcBuilders.standaloneSetup(profileController).build();

                // Prepare mock profile object
                long profileId = 1L;
                Profile existingProfile = new Profile("Bio", "profile_pic_url", newUser);
                existingProfile.setProfile_ID(profileId);
                Profile updatedProfile = new Profile("Updated Bio", "updated_profile_pic_url", newUser);

                // Mock repository behavior
                when(profileRepository.findById(profileId)).thenReturn(Optional.of(existingProfile));
                when(profileRepository.save(any(Profile.class))).thenReturn(updatedProfile);

                // Construct JSON content for updated profile
                String content = "{\"bio\":\"Updated Bio\",\"profile_picture\":\"updated_profile_pic_url\",\"first_name\":\"John\",\"last_name\":\"Doe\",\"email\":\"john@example.com\",\"password\":\"password\",\"gender\":\"MALE\",\"date_of_birth\":\"1990-01-01\",\"location\":\"Location\",\"phone_number\":\"1234567890\"}";

                // Perform mockMvc request
                mockMvc.perform(put("/profiles/{id}", profileId)
                                .header("Authorization", "Bearer " + token)
                                .content(content)
                                .contentType(MediaType.APPLICATION_JSON))
                                .andExpect(status().isOk())
                                .andExpect(jsonPath("$.bio").value("Updated Bio"))
                                .andExpect(jsonPath("$.profile_picture").value("updated_profile_pic_url"));

                // Verify repository method invocation
                verify(profileRepository, times(1)).findById(profileId);
                verify(profileRepository, times(1)).save(any(Profile.class));
        }
}
