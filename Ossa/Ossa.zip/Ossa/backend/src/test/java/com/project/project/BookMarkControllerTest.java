// package com.project.project;

// import static io.restassured.RestAssured.*;
// import static org.junit.jupiter.api.Assertions.*;
// import static org.mockito.Mockito.*;
// import static org.mockito.Mockito.when;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// import java.io.File;
// import java.io.FileInputStream;
// import java.io.IOException;
// import java.nio.file.Files;
// import java.nio.file.Path;
// import java.nio.file.Paths;
// import java.sql.Blob;
// import java.time.LocalDate;
// import java.time.LocalDateTime;
// import java.util.*;

// import org.junit.jupiter.api.BeforeAll;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.http.ResponseEntity;
// import org.springframework.jdbc.core.JdbcTemplate;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
// import com.project.project.BookMark.BookMark;
// import com.project.project.BookMark.BookMarkController;
// import com.project.project.BookMark.BookMarkRepository;
// import com.project.project.Post.Post;
// import com.project.project.Post.PostRepository;
// import com.project.project.Post.PostType;
// import com.project.project.Post.Privacy;
// import com.project.project.User.Gender;
// import com.project.project.User.User;
// import com.project.project.User.UserRepository;

// import io.restassured.http.ContentType;
// import io.restassured.response.Response;

// @SuppressWarnings("all")
// @SpringBootTest
// @AutoConfigureMockMvc
// class BookMarkControllerTest {

//     @Autowired
//     private MockMvc mockMvc;

//     @Mock
//     private BookMarkRepository bookMarkRepository;

//     @Mock
//     private UserRepository userRepository;

//     @Mock
//     private PostRepository postRepository;

//     @InjectMocks
//     private BookMarkController bookMarkController;

//     @Autowired
//     private JdbcTemplate jdbcTemplate = new JdbcTemplate();

//     private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

//     private User user = new User("zainab_turshan", "Zainab", "Turshan", "zainab@example.com", "Zainab123",
//             Gender.FEMALE, LocalDate.of(1993, 9, 15), "Bethlehem", "+970123456789");

//     // Adding posts
//     List<Blob> images = new ArrayList<>();
//     Path imagePath = Paths.get("C:\\Users\\Microsoft\\OneDrive\\Desktop\\free-nature-images.jpg");

//         try {
//             byte[] imageData = Files.readAllBytes(imagePath);
//             Blob imageBlob = new javax.sql.rowset.serial.SerialBlob(imageData);
//             // Now you can use the 'imageBlob' object as needed
//         } catch (IOException e) {
//             System.err.println("Error reading image file: " + e.getMessage());
//         }
//     images.add(imageBlob);
    
//     // Creating the Post object
//     private Post post = new Post(PostType.TEXT,images, "Sample post content", LocalDateTime.now(), user, Privacy.PUBLIC);

//     private BookMark bookMark = new BookMark(LocalDateTime.now(), post, user);

//     private static String token;

//     @BeforeAll
//     public static void setup() {
//         // Send sign-in request and extract token

//         Response response = given().contentType(ContentType.JSON)
//                 .body("{\"username\":\"john_doe123\",\"password\":\"password\"}").when()
//                 .post("http://localhost:8080/api/auth/signin").then().extract().response();

//         token = response.jsonPath().getString("accessToken");
//         assertNotNull(token); // Ensure token is not null

//     }

//     // Test case for retrieving all bookmarks
//     @Test

//     void testGetAllPosts() throws Exception {

//         this.mockMvc.perform(get("/bookmarks").header("Authorization", "Bearer " + token))
//                 .andExpect(MockMvcResultMatchers.status().isOk());
//     }

//     // Test case for creating a new bookmark
//     @Test
//     public void testNewBookMark() throws Exception {
//         // Register the JavaTimeModule for object mapping
//         objectMapper.registerModule(new JavaTimeModule());

//         // Build the MockMvc instance
//         mockMvc = MockMvcBuilders.standaloneSetup(bookMarkController).build();

//         // Mock bookmark data
//         Long userId = 1L;
//         Long postId = 1L;
//         post.setPost_ID(postId);
//         user.setUser_ID(userId);
//         bookMark.setUser(user);
//         BookMark bookMark = new BookMark();

//         // Mock optional user and post
//         Optional<User> optionalUser = Optional.of(user);
//         Optional<Post> optionalPost = Optional.of(post);

//         // Mock the findById method of the user repository
//         when(userRepository.findById(userId)).thenReturn(optionalUser);

//         // Mock the findById method of the post repository
//         when(postRepository.findById(postId)).thenReturn(optionalPost);

//         // Mock the save method of the repository
//         when(bookMarkRepository.save(bookMark)).thenReturn(bookMark);
//         ResponseEntity<BookMark> responseEntity = bookMarkController.newBookmark(bookMark, post.getPost_ID(),
//                 user.getUser_ID());
//         // Verify that the save method is called
//         verify(bookMarkRepository, times(1)).save(bookMark);

//         // Create a JSON representation of the BookMark object
//         String bookMarkJson = "{\"userId\": " + userId + ", \"postId\": " + postId + "}";

//         // Perform the POST request
//         mockMvc.perform(post("/bookmarks/post/{postId}/user/{userId}", userId, postId)
//                 .header("Authorization", "Bearer " + token)
//                 .contentType(MediaType.APPLICATION_JSON)
//                 .content(bookMarkJson)) // Send the JSON representation of the BookMark object
//                 .andExpect(status().isCreated());
//     }

//     // Test case for retrieving a bookmark by ID
//     @Test
//     void testGetBookMarkById_Successful() throws Exception {
//         // Set the ID of the bookmark you want to fetch
//         Long bookMarkId = 1L;

//         // Perform a GET request to fetch the bookmark by its ID
//         mockMvc.perform(get("/bookmarks/" + bookMarkId).header("Authorization", "Bearer " + token)
//                 .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
//     }

//     @Test
//     public void testGetBookmarksOnPost() throws Exception {
//         // Prepare test data
//         long postId = 1L;
//         post.setPost_ID(postId);

//         // Perform GET request
//         mockMvc.perform(get("/bookmarks/post/{postId}", postId).header("Authorization", "Bearer " + token))
//                 .andExpect(status().isOk());
//     }

//     @Test
//     public void testGetBookMarksByUser() throws Exception {
//         user.setUser_ID(1L);

//         // Perform the GET request
//         this.mockMvc.perform(get("/bookmarks/user/{userId}", user.getUser_ID())
//                 .header("Authorization", "Bearer " + token))
//                 .andExpect(MockMvcResultMatchers.status().isOk()); // Assuming this is the relation name for all
//                                                                    // bookMarks
//     }

//     // Test case for deleting a bookmark
//     @Test
//     public void testDeleteBookMark_Successful() throws Exception {
//         // Define the bookmark ID
//         Long bookmarkId = 1L;
//         bookMark.setBookMarkId(bookmarkId);

//         // Perform DELETE request

//         mockMvc.perform(MockMvcRequestBuilders.delete("/bookmarks/{id}", bookmarkId)
//                 .header("Authorization", "Bearer " + token) // Set the authorization header correctly
//                 .contentType(MediaType.APPLICATION_JSON))
//                 .andExpect(status().isNoContent()); // Expecting status code 204
//     }
// }