// package com.project.project;

// import static io.restassured.RestAssured.given;
// import static org.junit.jupiter.api.Assertions.assertNotNull;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
// import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// import org.junit.jupiter.api.BeforeAll;
// import org.junit.jupiter.api.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.http.ResponseEntity;
// import org.springframework.jdbc.core.JdbcTemplate;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.ResultActions;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
// import com.project.project.Notification.*;
// import com.project.project.User.*;
// import com.project.project.Post.*;
// import com.project.project.CommentLike.*;
// import com.project.project.Comment.*;

// import io.restassured.http.ContentType;
// import io.restassured.response.Response;

// import java.time.*;
// import java.util.*;

// import static org.mockito.Mockito.*;

// @SuppressWarnings("all")
// @SpringBootTest
// @AutoConfigureMockMvc
// public class CommentLikeControllerTest {
//         @Autowired
//         private MockMvc mockMvc;

//         @Mock
//         private UserRepository userRepository;

//         @Mock
//         private PostRepository postRepository;

//         @Mock
//         private CommentRepository commentRepository;

//         @Mock
//         private CommentLikeRepository commentLikeRepository;

//         @Mock
//         private NotificationRepository notificationRepository;

//         @InjectMocks
//         private CommentLikeController commentLikeController;

//         @InjectMocks
//         private UserController userController;

//         @Autowired
//         private JdbcTemplate jdbcTemplate = new JdbcTemplate();

//         private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

//         private User user = new User("joana_doe", "Joana", "Doe", "joana@example.com", "password", Gender.MALE,
//                         LocalDate.of(1990, 1, 1), "Location", "1234567890");
//         private Post post = new Post(PostType.TEXT, "Sample comment content", LocalDateTime.now(), user,
//                         Privacy.PUBLIC);
//         private Comment comment = new Comment("This is a comment", LocalDateTime.now(), user, post);
//         private CommentLike commentLike = new CommentLike(LocalDateTime.of(2024, 3, 30, 5, 30), user, comment);

//         private static String token;

//         @BeforeAll
//         public static void setup() {
//                 // Send sign-in request and extract token

//                 Response response = given()
//                                 .contentType(ContentType.JSON)
//                                 .body("{\"username\":\"john_doe123\",\"password\":\"password\"}")
//                                 .when()
//                                 .post("http://localhost:8080/api/auth/signin")
//                                 .then()
//                                 .extract()
//                                 .response();

//                 token = response.jsonPath().getString("accessToken");
//                 assertNotNull(token); // Ensure token is not null

//         }

//         @Test
//         void testGetAllComments() throws Exception {

//                 this.mockMvc.perform(get("/likes").header("Authorization", "Bearer " + token))
//                                 .andExpect(MockMvcResultMatchers.status().isOk());
//         }

//         @Test
//         public void testNewCommentLike() throws Exception {
//                 objectMapper.registerModule(new JavaTimeModule());
//                 mockMvc = MockMvcBuilders.standaloneSetup(commentLikeController).build();
//                 // Mock user and comment
//                 Long commentId = 1L;
//                 Long userId = 1L;
//                 Long postId = 1L;
//                 CommentLikeID commentLikeId = new CommentLikeID(userId, commentId);
//                 comment.setComment_ID(commentId);
//                 user.setUser_ID(userId);
//                 post.setPost_ID(postId);
//                 commentLike.setLikeID(commentLikeId);

//                 // Mock optional user and comment
//                 Optional<User> optionalUser = Optional.of(user);
//                 Optional<Comment> optionalComment = Optional.of(comment);
//                 Optional<Post> optionalPost = Optional.of(post);

//                 // Mock the findById method of the user repository
//                 when(userRepository.findById(user.getUser_ID())).thenReturn(optionalUser);

//                 // Mock the findById method of the comment repository
//                 when(commentRepository.findById(comment.getComment_ID())).thenReturn(optionalComment);

//                 // Mock the findById method of the post repository
//                 when(postRepository.findById(post.getPost_ID())).thenReturn(optionalPost);

//                 // Mock the save method of the repository
//                 when(commentLikeRepository.save(commentLike)).thenReturn(commentLike);
//                 ResponseEntity<CommentLike> responseEntity = commentLikeController.newLike(commentLike,
//                                 comment.getComment_ID(), user.getUser_ID());
//                 // Verify that the save method is called
//                 verify(commentLikeRepository, times(1)).save(commentLike);

//                 // Create a JSON representation of the CommentLike object
//                 String commentLikeJson = "{\"likeID\": {\"userId\": " + user.getUser_ID() + ", \"commentId\": "
//                                 + comment.getComment_ID()
//                                 + "}, " +
//                                 "\"timestamp\": \"2024-03-30T05:30:00\"}";

//                 // Perform the POST request
//                 mockMvc.perform(MockMvcRequestBuilders
//                                 .post("/likes/comment/{commentId}/user/{userId}", comment.getComment_ID(),
//                                                 user.getUser_ID())
//                                 .header("Authorization", "Bearer " + token)
//                                 .contentType(MediaType.APPLICATION_JSON)
//                                 .content(commentLikeJson)) // Send the JSON representation of the CommentLike object
//                                 .andExpect(status().isCreated())
//                                 .andExpect(jsonPath("$.errors").doesNotExist()); // Expect no validation errors

//         }

//         @Test
//         public void testGetCommentLikesOnComment() throws Exception {
//                 // Mock CommentLike objects
//                 CommentLike commentLike1 = new CommentLike(LocalDateTime.now(), user, comment);
//                 CommentLike commentLike2 = new CommentLike(LocalDateTime.now(), user, comment);
//                 List<CommentLike> likes = Arrays.asList(commentLike1, commentLike2);
//                 comment.setComment_ID(1L);

//                 // Mock the findAll method of the repository to return the list of CommentLikes
//                 when(commentLikeRepository.findAll()).thenReturn(likes);

//                 // Perform the GET request
//                 this.mockMvc.perform(get("/likes/comment/{commentId}", comment.getComment_ID())
//                                 .header("Authorization", "Bearer " + token))
//                                 .andExpect(MockMvcResultMatchers.status().isOk()); // Assuming this is the relation name
//                                                                                    // for all likes
//         }

//         @Test
//         public void testGetCommentLikesByUser() throws Exception {
//                 // Mock CommentLike objects
//                 CommentLike commentLike1 = new CommentLike(LocalDateTime.now(), user, comment);
//                 CommentLike commentLike2 = new CommentLike(LocalDateTime.now(), user, comment);
//                 List<CommentLike> likes = Arrays.asList(commentLike1, commentLike2);
//                 user.setUser_ID(1L);

//                 // Mock the findAll method of the repository to return the list of CommentLikes
//                 when(commentLikeRepository.findAll()).thenReturn(likes);

//                 // Perform the GET request
//                 this.mockMvc.perform(get("/likes/user/{userId}", user.getUser_ID())
//                                 .header("Authorization", "Bearer " + token))
//                                 .andExpect(MockMvcResultMatchers.status().isOk()); // Assuming this is the relation name
//                                                                                    // for all likes
//         }

//         @Test
//         void testGetsOneCommentLike() throws Exception {
//                 mockMvc = MockMvcBuilders.standaloneSetup(commentLikeController).build();

//                 // Create sample data
//                 Long commentId = 1L;
//                 Long userId = 1L;
//                 CommentLikeID commentLikeId = new CommentLikeID(userId, commentId);
//                 comment.setComment_ID(commentId);
//                 user.setUser_ID(userId);
//                 commentLike.setLikeID(commentLikeId);

//                 when(commentLikeRepository.findById(new CommentLikeID(1L, 1L))).thenReturn(Optional.of(commentLike));
//                 final ResultActions result = mockMvc
//                                 .perform(get("/likes/comment/{commentId}/user/{userId}", 1L, 1L).header("Authorization",
//                                                 "Bearer " + token));
//                 result.andExpect(status().isOk());
//         }

//         @Test
//         public void testDeleteCommentLike_Successful() throws Exception {
//                 Long commentId = 1L;
//                 Long userId = 1L;
//                 CommentLikeID commentLikeId = new CommentLikeID(userId, commentId);
//                 comment.setComment_ID(commentId);
//                 user.setUser_ID(userId);
//                 commentLike.setLikeID(commentLikeId);

//                 when(commentLikeRepository.findById(commentLikeId)).thenReturn(Optional.of(commentLike));
//                 when(commentLikeRepository.findById(commentLikeId)).thenReturn(Optional.of(commentLike));

//                 // Perform DELETE request
//                 mockMvc.perform(
//                                 delete("/likes/comment/{commentId}/user/{userId}", commentId.toString(),
//                                                 userId.toString()).header("Authorization", "Bearer " + token)
//                                                 .contentType(MediaType.APPLICATION_JSON))
//                                 .andExpect(status().isOk()); // Expecting 204 status code
//                 this.mockMvc
//                                 .perform(get("/likes/comment/{commentId}/user/{userId}", commentId.toString(),
//                                                 userId.toString()).header("Authorization", "Bearer " + token))
//                                 .andExpect(status().isNotFound());
//         }

// }
