package com.project.project.Notification;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@SuppressWarnings("all")
@RestController
public class NotificationController {

    @Autowired
    private static NotificationRepository repository;

    public NotificationController(NotificationRepository repository) {
        this.repository = repository;
    }

    // Aggregate root
    @GetMapping("/notifications")
    CollectionModel<EntityModel<Notification>> all() {

        List<EntityModel<Notification>> notifications = repository.findAll().stream()
                .map(notification -> EntityModel.of(notification,
                        linkTo(methodOn(NotificationController.class).one(notification.getNotification_ID()))
                                .withSelfRel(),
                        linkTo(methodOn(NotificationController.class).all()).withRel("notifications")))
                .collect(Collectors.toList());

        return CollectionModel.of(notifications, linkTo(methodOn(NotificationController.class).all()).withSelfRel());
    }

    @PostMapping("/notifications")
    public ResponseEntity<Notification> newNotification(@RequestBody @Valid Notification newNotification) {
        Notification savedNotification = repository.save(newNotification);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedNotification);
    }

    // Single item
    @GetMapping("/notifications/{id}")
    EntityModel<Notification> one(@PathVariable Long id) {

        Notification notification = repository.findById(id)
                .orElseThrow(() -> new NotificationNotFoundException(id));

        return EntityModel.of(notification,
                linkTo(methodOn(NotificationController.class).one(id)).withSelfRel(),
                linkTo(methodOn(NotificationController.class).all()).withRel("notifications"));
    }

    @DeleteMapping("/notifications/{id}")
    ResponseEntity<?> deleteNotification(@PathVariable Long id) {
        return repository.findById(id)
                .map(notification -> {
                    repository.deleteById(id);
                    return ResponseEntity.noContent().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

}