package com.project.project.Home;

import jakarta.persistence.*;
import lombok.*;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.project.Post.Post;
import com.project.project.User.User;

@Entity
@Table
@ToString
@NoArgsConstructor
@Getter
@Setter
public class Home {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long home_ID;

    @JsonIgnore
    @OneToOne(mappedBy = "home", cascade = CascadeType.ALL)
    @JoinColumn(name = "user_ID")
    private User user;

    @ManyToMany(mappedBy = "homes", cascade = CascadeType.ALL)
    private List<Post> posts = new ArrayList<>();

    public Home(User user) {
        this.user = user;
        this.posts = new ArrayList<Post>();
    }

    public void addPost(Post post) {
        this.posts.add(post);
    }

}
