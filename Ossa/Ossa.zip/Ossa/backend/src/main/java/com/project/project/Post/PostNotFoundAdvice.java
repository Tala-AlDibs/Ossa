package com.project.project.Post;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
class PostNotFoundAdvice {

  @ResponseBody
  @ExceptionHandler(PostNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  String PostNotFoundHandler(PostNotFoundException ex) {
    return ex.getMessage();
  }
}
