package com.project.project.Messages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.project.project.Notification.*;
import com.project.project.User.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@SuppressWarnings("all")
@RestController
public class MessageController {

    @Autowired
    private final MessageRepository messageRepository;

    @Autowired
    private final UserRepository userRepository;

    @Autowired
    private final NotificationRepository notificationRepository;

    MessageController(MessageRepository messageRepository, UserRepository userRepository,
            NotificationRepository notificationRepository) {
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.notificationRepository = notificationRepository;
    }

    // Get all messages from the database and return them as a resource with links
    @GetMapping("/messages")
    public CollectionModel<EntityModel<Message>> getAllMessages() {
        List<EntityModel<Message>> messages = messageRepository.findAll().stream()
                .map(message -> EntityModel.of(message,
                        linkTo(methodOn(MessageController.class).getMessageById(message.getId())).withSelfRel()))
                .collect(Collectors.toList());

        return CollectionModel.of(messages, linkTo(methodOn(MessageController.class).getAllMessages()).withSelfRel());
    }

    // Get a single message by id
    @GetMapping("/messages/{id}")
    public ResponseEntity<EntityModel<Message>> getMessageById(@PathVariable Long id) {
        Optional<Message> messageOptional = messageRepository.findById(id);
        return messageOptional.map(message -> {
            return ResponseEntity.ok(EntityModel.of(message,
                    linkTo(methodOn(MessageController.class).getMessageById(id)).withSelfRel(),
                    linkTo(methodOn(MessageController.class).getAllMessages()).withRel("messages")));
        }).orElse(ResponseEntity.notFound().build());
    }

    // Create a new message and save it to the database
    @PostMapping("/messages/sender/{senderId}/receiver/{receiverId}")
    public ResponseEntity<Message> createMessage(@RequestBody Message message, @PathVariable Long senderId,
            @PathVariable Long receiverId) {
        Optional<User> optionalSender = userRepository.findById(senderId);
        Optional<User> optionalReciever = userRepository.findById(receiverId);
        if (optionalSender.isPresent() && optionalReciever.isPresent()) {
            User sender = optionalSender.get();
            User receiver = optionalReciever.get();
            message.setSender(sender);
            message.setRecipient(receiver);
            message.setReadTimestamp(LocalDateTime.now());
            message.setTimestamp(LocalDateTime.now());
            Notification notification = new Notification(LocalDateTime.now(),
                    sender.getUsername() + ": " + message.getContent(), NotificationType.MESSAGE);
            notificationRepository.save(notification);

            Message savedMessage = messageRepository.save(message);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedMessage);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Update a message in the database
    @PutMapping("/messages/{id}")
    public ResponseEntity<Message> updateMessage(@PathVariable Long id, @RequestBody Message updatedMessage) {
        Optional<Message> existingMessageOptional = messageRepository.findById(id);
        if (existingMessageOptional.isPresent()) {
            Message existingMessage = existingMessageOptional.get();
            existingMessage.setContent(updatedMessage.getContent());
            existingMessage.setTimestamp(updatedMessage.getTimestamp());
            existingMessage.setStatus(updatedMessage.getStatus());
            return ResponseEntity.ok(messageRepository.save(existingMessage));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete a message from the database
    @DeleteMapping("/messages/{id}")
    public ResponseEntity<Void> deleteMessage(@PathVariable Long id) {
        messageRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

}
