package com.project.project.Profile;

class ProfileNotFoundException extends RuntimeException {

  ProfileNotFoundException(Long id) {
    super("Could not find Profile " + id);
  }
}