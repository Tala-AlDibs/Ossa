package com.project.project.User;

import java.time.LocalDate;
import java.util.*;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.project.BookMark.BookMark;
import com.project.project.Comment.Comment;
import com.project.project.Home.Home;
import com.project.project.Messages.Message;
import com.project.project.Post.*;
import com.project.project.Profile.Profile;
import com.project.project.React.React;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "username", "email", "phone_number" }))
@NoArgsConstructor
@ToString
@Getter
@Setter
public class User {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  protected Long user_ID;
  @NotBlank
  @Size(max = 20)
  private String username;
  protected String first_name;
  protected String last_name;
  @NotBlank
  @Size(max = 50)
  @Email
  private String email;
  @NotBlank
  @Size(max = 120)
  private String password;

  protected Gender gender;
  protected LocalDate date_of_birth;
  protected String location;
  protected String phone_number;
  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
  private List<Post> posts = new ArrayList<>();
  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
  private List<React> reacts = new ArrayList<>();
  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
  private List<Comment> comments = new ArrayList<>();

  @JsonIgnore
  @OneToOne(cascade = CascadeType.ALL)
  private Profile profile;

  @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
  private List<BookMark> bookMarks = new ArrayList<>();

  @JsonIgnore
  @OneToOne(cascade = CascadeType.ALL)
  private Home home;

  @ManyToMany
  @JoinTable(name = "friendship", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "friend_id"))
  private List<User> friends = new ArrayList<>();

  @ManyToMany(mappedBy = "friends")
  private List<User> friendRequests = new ArrayList<>();

  @OneToMany(mappedBy = "sender", cascade = CascadeType.ALL)
  private List<Message> receivedMessages = new ArrayList<>();
  @OneToMany(mappedBy = "recipient", cascade = CascadeType.ALL)
  private List<Message> sentMessages = new ArrayList<>();

  public User(String username, String first_name, String last_name,
      String email, String password, Gender gender,
      LocalDate date_of_birth, String location, String phone_number) {
    this.username = username;
    this.first_name = first_name;
    this.last_name = last_name;
    this.email = email;
    this.password = password;
    this.gender = gender;
    this.date_of_birth = date_of_birth;
    this.location = location;
    this.phone_number = phone_number;
    this.posts = new ArrayList<>();
    this.reacts = new ArrayList<>();
    this.comments = new ArrayList<>();
    this.friends = new ArrayList<>();
    this.friendRequests = new ArrayList<>();
    this.receivedMessages = new ArrayList<>();
    this.sentMessages = new ArrayList<>();
    this.bookMarks = new ArrayList<>();
  }

  // Example method in a service
  public void addPost(Post post) {
    posts.add(post);
  }

  public void addFriend(User friend) {
    if (friends == null)
      friends = new ArrayList<>();
    if (friendRequests == null)
      friendRequests = new ArrayList<>();
    friends.add(friend);
    friends.add(friend);
    friend.getFriends().add(this);
  }

  public void addBookmark (BookMark bookmark) {
    this.bookMarks.add(bookmark);
}

}