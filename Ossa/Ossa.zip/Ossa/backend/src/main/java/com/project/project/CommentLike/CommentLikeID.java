package com.project.project.CommentLike;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class CommentLikeID implements Serializable {

    private Long userId;
    private Long commentId;

    // Default constructor (required by JPA)
    public CommentLikeID() {
    }

    // Constructor with userId and commentId parameters
    public CommentLikeID(Long userId, Long commentId) {
        this.userId = userId;
        this.commentId = commentId;
    }

    // Override equals and hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        CommentLikeID likeId = (CommentLikeID) o;
        return Objects.equals(userId, likeId.userId) && Objects.equals(commentId, likeId.commentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, commentId);
    }
}
