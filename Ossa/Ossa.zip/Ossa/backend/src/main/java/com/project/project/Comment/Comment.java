package com.project.project.Comment;

import java.time.LocalDateTime;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;

import com.project.project.User.User;
import com.project.project.CommentLike.CommentLike;
import com.project.project.Post.Post;

@Entity
@Table
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Comment_ID;

    @Size(min = 1, max = 500, message = "Comment shouldn't be empty nor exceed 500 characters")
    private String content;
    private LocalDateTime datePosted;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "user_ID", nullable = false)
    private User user;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "post_ID", nullable = false)
    private Post post;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "parent_comment_id")
    private Comment parentComment;
    @OneToMany(mappedBy = "parentComment", cascade = CascadeType.ALL)
    private List<Comment> replies = new ArrayList<>();

    @OneToMany(mappedBy = "comment", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CommentLike> likes = new ArrayList<>();

    public Comment(String content, LocalDateTime datePosted, User user, Post post, Comment parentComment) {
        this.content = content;
        this.datePosted = datePosted;
        this.user = user;
        this.post = post;
        this.parentComment = parentComment;
        this.replies = new ArrayList<>();
        this.likes = new ArrayList<>();
    }

    public Comment(String content, LocalDateTime datePosted, User user, Post post) {
        this.content = content;
        this.datePosted = datePosted;
        this.user = user;
        this.post = post;
        this.replies = new ArrayList<>();
    }

}