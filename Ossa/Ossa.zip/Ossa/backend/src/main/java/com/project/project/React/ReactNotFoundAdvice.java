package com.project.project.React;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
class ReactNotFoundAdvice {

  @ResponseBody
  @ExceptionHandler(ReactNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  String ReactNotFoundHandler(ReactNotFoundException ex) {
    return ex.getMessage();
  }
}
