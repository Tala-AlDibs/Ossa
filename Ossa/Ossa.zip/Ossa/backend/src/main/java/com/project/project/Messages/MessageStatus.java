package com.project.project.Messages;

public enum MessageStatus {
    seen, delivered, undelivered

}
