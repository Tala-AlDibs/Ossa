package com.project.project.Notification;

public enum NotificationType {
    MESSAGE, FOLLOW, REACT, COMMENT, POST, REPLY
}
