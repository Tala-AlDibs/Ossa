package com.project.project.React;

class ReactNotFoundException extends RuntimeException {

    ReactNotFoundException(Long postId, Long userId) {
        super("Could not find Reaction for Post ID: " + postId + " and User ID: " + userId);
    }
}
