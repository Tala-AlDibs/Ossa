package com.project.project.payload.request;

import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.project.project.Profile.Profile;
import com.project.project.User.*;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class SignupRequest {
  @NotBlank
  @Size(min = 3, max = 20)
  private String username;

  protected String first_name;
  protected String last_name;

  @NotBlank
  @Size(max = 50)
  @Email
  private String email;

  @NotBlank
  @Size(min = 6, max = 40)
  private String password;

  @JsonDeserialize(using = GenderDeserializer.class)
  private Gender gender;
  private LocalDate date_of_birth;
  private String location;
  private String phone_number;
  private Profile profile;

}
