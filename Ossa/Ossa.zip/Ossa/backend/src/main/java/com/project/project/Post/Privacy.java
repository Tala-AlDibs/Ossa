package com.project.project.Post;

public enum Privacy {
    PRIVATE, PUBLIC, FRIENDS
}
