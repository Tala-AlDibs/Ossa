package com.project.project.Profile;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.project.Post.*;
import com.project.project.User.*;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "first_name", "last_name", "email", "password",
        "phone_number" }))
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class Profile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long profile_ID;
    @NotBlank(message = "Bio is required")

    private String bio;
    @NotBlank(message = "First name is required")

    protected String first_name;
    @NotBlank(message = "Last name is required")
    protected String last_name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    protected String email;
    @NotBlank(message = "Password is required")
    protected String password;
    protected String profile_picture;

    @NotNull(message = "Gender is required")
    protected Gender gender;
    @NotNull(message = "Date of birth is required")
    protected LocalDate date_of_birth;
    protected String location;
    @Pattern(regexp = "\\d{10}", message = "Phone number must be 10 digits")
    protected String phone_number;
    @JsonIgnore
    @OneToOne(mappedBy = "profile", cascade = CascadeType.ALL)
    @JoinColumn(name = "user_ID")
    private User user;

    @OneToMany(mappedBy = "profile", cascade = CascadeType.ALL)
    private List<Post> posts;

    public Profile(String bio, String profile_picture, User user) {
        this.bio = bio;
        this.first_name = user.getFirst_name();
        this.last_name = user.getLast_name();
        this.email = user.getEmail();
        this.password = user.getPassword();
        this.profile_picture = profile_picture;
        this.gender = user.getGender();
        this.date_of_birth = user.getDate_of_birth();
        this.location = user.getLocation();
        this.phone_number = user.getPhone_number();
        this.user = user;
        this.posts = new ArrayList<Post>();
    }

    public String UserName() {
        return this.first_name + " " + this.last_name;
    }

    public int age() {
        if (date_of_birth == null)
            throw new IllegalStateException("User's birthday is not set");

        LocalDate today = LocalDate.now();

        int age = Period.between(date_of_birth, today).getYears();

        return age;

    }

    public String birthday() {
        if (date_of_birth == null)
            throw new IllegalStateException("User's birthday is not set");

        LocalDate today = LocalDate.now();
        LocalDate birthdayThisYear = date_of_birth.withYear(today.getYear());
        if (today.isAfter(birthdayThisYear)) {
            // If birthday has already occurred this year, calculate for next year
            birthdayThisYear = birthdayThisYear.plusYears(1);
        }

        long daysUntilBirthday = ChronoUnit.DAYS.between(today, birthdayThisYear);

        if (daysUntilBirthday == 1) {
            return "Your birthday is tomorrow!";
        } else {
            return "Your birthday is in " + daysUntilBirthday + " days.";
        }
    }

    public void addPost(Post post) {
        posts.add(post);
    }

}