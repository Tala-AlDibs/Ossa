package com.project.project.CommentLike;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
class CommentLikeNotFoundAdvice {

  @ResponseBody
  @ExceptionHandler(CommentLikeNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  String ReactNotFoundHandler(CommentLikeNotFoundException ex) {
    return ex.getMessage();
  }
}
