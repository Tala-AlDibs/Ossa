package com.project.project.Post;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import javax.sql.rowset.serial.SerialBlob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.hateoas.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

import com.project.project.Post.Post;
import com.project.project.BookMark.*;
import com.project.project.Comment.*;
import com.project.project.Home.*;
import com.project.project.Notification.*;
import com.project.project.User.*;

@SuppressWarnings("all")
@RestController
public class PostController {

  @Autowired
  private final PostRepository repository;

  @Autowired
  private final UserRepository userRepository;

  @Autowired
  private final NotificationRepository notificationRepository;

  PostController(PostRepository repository, UserRepository userRepository,
      NotificationRepository notificationRepository) {
    this.repository = repository;
    this.userRepository = userRepository;
    this.notificationRepository = notificationRepository;
  }

  // Aggregate root - Get all posts
  // tag::get-aggregate-root[]
  @GetMapping("/posts")
  @CrossOrigin(origins = "http://localhost:3000")
  CollectionModel<EntityModel<Post>> all() {

    List<EntityModel<Post>> posts = repository.findAll().stream()
        .map(post -> EntityModel.of(post,
            linkTo(methodOn(PostController.class).one(post.getPost_ID())).withSelfRel(),
            linkTo(methodOn(PostController.class).all()).withRel("Posts")))
        .collect(Collectors.toList());

    return CollectionModel.of(posts, linkTo(methodOn(PostController.class).all()).withSelfRel());
  }

  // Post a new post by a user
  // Post a new post by a user
  @PostMapping(value = "/posts/{userId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@CrossOrigin(origins = "http://localhost:3000")
public ResponseEntity<Post> newPost(@RequestPart("post") Post newPost,
                                     @RequestPart("file") MultipartFile file,
                                     @PathVariable Long userId) {
    Optional<User> optionalUser = userRepository.findById(userId);
   try {
    // Convert the byte array to a Blob object
    Blob imageBlob = new SerialBlob(file.getBytes());
    // Set the Blob object in the Post object
    newPost.setImage(imageBlob);
} catch (IOException | SQLException e) {
    // Handle the exception (e.g., log the error or return an error response)
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
}

    if (optionalUser.isPresent()) {
        User user = optionalUser.get();
        newPost.setUser(user); // Set the user for the new post
        user.addPost(newPost);
        com.project.project.Profile.Profile userProfile = user.getProfile();
        newPost.setProfile(userProfile);
        userProfile.addPost(newPost);
        List<User> allUsers = userRepository.findAll();
        for (User u : allUsers) {
            if (!u.equals(user)) {
                Home home = u.getHome();
                if (home != null) { // Check if the user is not the post owner
                    newPost.addHome(home);
                }
            }
        }
        newPost.setTimestamp(LocalDateTime.now());
        
        // Depending on the post type, set appropriate fields
        switch(newPost.getPost_type()) {
          case TEXT:
              // For text posts, only set the description
              newPost.setImage(null); // Make sure to set image to null or an empty list
              break;
          case IMAGE:
              // For image posts, set only the image field
              newPost.setDescription(null); // Make sure to set description to null or an empty string
              break;
          case TEXTIMAGE:
              // For text and image posts, set both description and image
              // Your logic to set the fields accordingly
              break;
          // Add cases for other post types as needed
      }
      
        
        // Save the post
        Post savedPost = repository.save(newPost);

        Notification notification = new Notification(LocalDateTime.now(), "New post from " + user.getUsername(),
            NotificationType.POST);
        notificationRepository.save(notification);

        return ResponseEntity.status(HttpStatus.CREATED).body(savedPost);
    } else {
        // Handle the case when the user with the given ID is not found
        // You can throw an exception or return an appropriate response
        // Here, I'm returning null as an indication of failure
        return null;
    }
}


  // Single item - Get a single post by id
  @GetMapping("/posts/{id}")
  @CrossOrigin(origins = "http://localhost:3000")
  EntityModel<Post> one(@PathVariable Long id) {

    Post post = repository.findById(id) //
        .orElseThrow(() -> new PostNotFoundException(id));

    return EntityModel.of(post, //
        linkTo(methodOn(PostController.class).one(id)).withSelfRel(),
        linkTo(methodOn(PostController.class).all()).withRel("Posts"));
  }

  // Update a post
  @PutMapping("/posts/{id}")
  @CrossOrigin(origins = "http://localhost:3000")
  Post replacePost(@RequestBody Post newPost, @PathVariable long id) {

    return repository.findById(id)
        .map(post -> {
          post.setPost_type(newPost.getPost_type());
          post.setDescription(newPost.getDescription());
          post.setImage(newPost.getImage());
          post.setTimestamp(LocalDateTime.now());
          post.setPrivacy(newPost.getPrivacy());
          return repository.save(post);
        })
        .orElseGet(() -> {
          newPost.setPost_ID(id);
          newPost.setTimestamp(LocalDateTime.now());
          return repository.save(newPost);
        });
  }

  // Delete a post
  @DeleteMapping("/posts/{id}")
  @CrossOrigin(origins = "http://localhost:3000")
  ResponseEntity<?> deletePost(@PathVariable Long id) {
    Optional<Post> optionalPost = repository.findById(id);
    if (optionalPost.isPresent()) {
      Post post = optionalPost.get();

      // Remove all comments associated with the post
      post.getComments().clear();
      post.getReacts().clear();

      repository.deleteById(id); // Delete the post
      return ResponseEntity.noContent().build();
    } else {
      return ResponseEntity.notFound().build();
    }
  }

}
