package com.project.project.CommentLike;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.project.User.*;
import com.project.project.Notification.*;
import com.project.project.Comment.*;

@SuppressWarnings("all")
@RestController
public class CommentLikeController {

  @Autowired
  private final CommentLikeRepository repository;

  @Autowired
  private final UserRepository userRepository;

  @Autowired
  private final CommentRepository commentRepository;

  @Autowired
  private final NotificationRepository notificationRepository;

  CommentLikeController(CommentLikeRepository repository, UserRepository userRepository,
      CommentRepository commentRepository,
      NotificationRepository notificationRepository) {
    this.repository = repository;
    this.commentRepository = commentRepository;
    this.userRepository = userRepository;
    this.notificationRepository = notificationRepository;
  }

  // Aggregate root - Get all likes
  // tag::get-aggregate-root[]
  @GetMapping("/likes")
  CollectionModel<EntityModel<CommentLike>> all() {

    List<EntityModel<CommentLike>> likes = repository.findAll().stream()
        .map(like -> EntityModel.of(like,
            linkTo(methodOn(CommentLikeController.class).one(like.getCommentId(), like.getUserId())).withSelfRel(),
            linkTo(methodOn(CommentLikeController.class).all()).withRel("likes")))
        .collect(Collectors.toList());

    return CollectionModel.of(likes, linkTo(methodOn(CommentLikeController.class).all()).withSelfRel());
  }

  // Post a new like on a comment by a user
  @PostMapping("/likes/comment/{commentId}/user/{userId}")
  public ResponseEntity<CommentLike> newLike(@RequestBody CommentLike newLike, @PathVariable Long commentId,
      @PathVariable Long userId) {
    Optional<User> optionalUser = userRepository.findById(userId);
    Optional<Comment> optionalComment = commentRepository.findById(commentId);
    if (optionalUser.isPresent() && optionalComment.isPresent()) {
      CommentLikeID likeId = new CommentLikeID(userId, commentId);
      newLike.setLikeID(likeId);
      User user = optionalUser.get();
      newLike.setUser(user); // Set the user for the new like
      Comment comment = optionalComment.get();
      newLike.setComment(comment);
      newLike.setTimestamp(LocalDateTime.now());
      Notification notification = new Notification(LocalDateTime.now(),
          user.getUsername() + " liked " + comment.getUser().getUsername() + "'s comment", NotificationType.REACT);
      notificationRepository.save(notification);
      return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(newLike));
    } else {
      return null;
    }

  }

  // Get all likes on a comment
  @GetMapping("/likes/comment/{commentId}")
  public CollectionModel<EntityModel<CommentLike>> getLikesOnComment(@PathVariable Long commentId) {
    List<EntityModel<CommentLike>> likes = repository.findAll().stream()
        .filter(like -> like.getComment().getComment_ID().equals(commentId))
        .map(like -> EntityModel.of(like,
            linkTo(methodOn(CommentLikeController.class).one(like.getCommentId(), like.getUserId())).withSelfRel(),
            linkTo(methodOn(CommentLikeController.class).all()).withRel("Likes")))
        .collect(Collectors.toList());

    return CollectionModel.of(likes, linkTo(methodOn(CommentLikeController.class).all()).withSelfRel());
  }

  // Get all likes by a user
  @GetMapping("/likes/user/{userId}")
  public CollectionModel<EntityModel<CommentLike>> likesByUser(@PathVariable Long userId) {
    List<EntityModel<CommentLike>> likes = repository.findAll().stream()
        .filter(like -> like.getUser().getUser_ID().equals(userId))
        .map(like -> EntityModel.of(like,
            linkTo(methodOn(CommentLikeController.class).one(like.getCommentId(), like.getUserId())).withSelfRel(),
            linkTo(methodOn(CommentLikeController.class).all()).withRel("Likes")))
        .collect(Collectors.toList());

    return CollectionModel.of(likes, linkTo(methodOn(CommentLikeController.class).all()).withSelfRel());
  }

  // Get a single like by comment ID and user ID
  @GetMapping("/likes/comment/{commentId}/user/{userId}")
  EntityModel<CommentLike> one(@PathVariable Long commentId, @PathVariable Long userId) {
    CommentLikeID likeID = new CommentLikeID(userId, commentId);

    CommentLike like = repository.findById(likeID) //
        .orElseThrow(() -> new CommentLikeNotFoundException(likeID.getUserId(), likeID.getCommentId()));

    return EntityModel.of(like, //
        linkTo(methodOn(CommentLikeController.class).one(commentId, userId)).withSelfRel(),
        linkTo(methodOn(CommentLikeController.class).all()).withRel("likes"));
  }

  // Delete a like by comment ID and user ID
  @DeleteMapping("/likes/comment/{commentId}/user/{userId}")
  void deleteLike(@PathVariable Long commentId, @PathVariable Long userId) {
    repository.deleteById(new CommentLikeID(userId, commentId));
  }
}
