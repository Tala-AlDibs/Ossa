package com.project.project.React;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.project.Post.Post;
import com.project.project.User.User;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "user_ID", "post_ID" }))
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class React {
    @EmbeddedId
    private ReactID reaction_ID;
    private ReactionType reactionType;
    private LocalDateTime timestamp;

    @JsonIgnore
    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name = "user_ID")
    private User user;

    @JsonIgnore
    @ManyToOne
    @MapsId("postId")
    @JoinColumn(name = "post_ID")
    private Post post;

    public React(ReactionType reactionType, LocalDateTime timestamp) {
        this.reactionType = reactionType;
        this.timestamp = timestamp;
    }

    // Add methods to access PostId and UserId from the composite key
    public Long getPostId() {
        return reaction_ID.getPostId();
    }

    public Long getUserId() {
        return reaction_ID.getUserId();
    }
}
