package com.project.project.React;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.project.project.User.*;
import com.project.project.Notification.*;
import com.project.project.Post.*;

@SuppressWarnings("all")
@RestController
public class ReactController {

  @Autowired
  private final ReactRepository repository;

  @Autowired
  private final UserRepository userRepository;

  @Autowired
  private final PostRepository postRepository;

  @Autowired
  private final NotificationRepository notificationRepository;

  ReactController(ReactRepository repository, UserRepository userRepository, PostRepository postRepository,
      NotificationRepository notificationRepository) {
    this.repository = repository;
    this.postRepository = postRepository;
    this.userRepository = userRepository;
    this.notificationRepository = notificationRepository;
  }

  // Aggregate root
  // tag::get-aggregate-root[]
  @GetMapping("/reacts")
  CollectionModel<EntityModel<React>> all() {

    List<EntityModel<React>> reacts = repository.findAll().stream()
        .map(react -> EntityModel.of(react,
            linkTo(methodOn(ReactController.class).one(react.getPostId(), react.getUserId())).withSelfRel(),
            linkTo(methodOn(ReactController.class).all()).withRel("reacts")))
        .collect(Collectors.toList());

    return CollectionModel.of(reacts, linkTo(methodOn(ReactController.class).all()).withSelfRel());
  }

  // Post a new react resource by creating a new `React` instance and calling the
  // `ReactRepository#save()` method
  // to save it to the database.
  // The `React` instance is created with the `ReactID` instance as the primary key.
  @PostMapping("/reacts/post/{postId}/user/{userId}")
  public ResponseEntity<React> newReact(@RequestBody React newReact, @PathVariable Long postId,
      @PathVariable Long userId) {
    Optional<User> optionalUser = userRepository.findById(userId);
    Optional<Post> optionalPost = postRepository.findById(postId);
    if (optionalUser.isPresent() && optionalPost.isPresent()) {
      ReactID reactId = new ReactID(userId, postId);
      newReact.setReaction_ID(reactId);
      User user = optionalUser.get();
      newReact.setUser(user); // Set the user for the new react
      Post post = optionalPost.get();
      newReact.setPost(post);
      newReact.setTimestamp(LocalDateTime.now());
      Notification notification = new Notification(LocalDateTime.now(),
          user.getUsername() + " Reacted on " + post.getUser().getUsername() + "'s post", NotificationType.REACT);
      notificationRepository.save(notification);
      return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(newReact));
    } else {
      return null;
    }

  }

  // Get all reacts on a post by its id
  @GetMapping("/reacts/post/{postId}")
  public CollectionModel<EntityModel<React>> getReactsOnPost(@PathVariable Long postId) {
    List<EntityModel<React>> reacts = repository.findAll().stream()
        .filter(react -> react.getPost().getPost_ID().equals(postId))
        .map(react -> EntityModel.of(react,
            linkTo(methodOn(ReactController.class).one(react.getPostId(), react.getUserId())).withSelfRel(),
            linkTo(methodOn(ReactController.class).all()).withRel("Reacts")))
        .collect(Collectors.toList());

    return CollectionModel.of(reacts, linkTo(methodOn(ReactController.class).all()).withSelfRel());
  }

  // Get all reacts by a user
  @GetMapping("/reacts/user/{userId}")
  public CollectionModel<EntityModel<React>> reactsByUser(@PathVariable Long userId) {
    List<EntityModel<React>> reacts = repository.findAll().stream()
        .filter(react -> react.getUser().getUser_ID().equals(userId))
        .map(react -> EntityModel.of(react,
            linkTo(methodOn(ReactController.class).one(react.getPostId(), react.getUserId())).withSelfRel(),
            linkTo(methodOn(ReactController.class).all()).withRel("Reacts")))
        .collect(Collectors.toList());

    return CollectionModel.of(reacts, linkTo(methodOn(ReactController.class).all()).withSelfRel());
  }

  // Single item - Get a single react by its post id and user id
  @GetMapping("/reacts/post/{postId}/user/{userId}")
  EntityModel<React> one(@PathVariable Long postId, @PathVariable Long userId) {
    ReactID reactID = new ReactID(userId, postId);

    React react = repository.findById(reactID) //
        .orElseThrow(() -> new ReactNotFoundException(reactID.getUserId(), reactID.getPostId()));

    return EntityModel.of(react, //
        linkTo(methodOn(ReactController.class).one(postId, userId)).withSelfRel(),
        linkTo(methodOn(ReactController.class).all()).withRel("Reacts"));
  }

  // Update a react
  @PutMapping("/reacts/post/{postId}/user/{userId}")
  React replaceReact(@RequestBody React newReact, @PathVariable Long postId, @PathVariable Long userId) {

    return repository.findById(new ReactID(userId, postId))
        .map(react -> {
          react.setReactionType(newReact.getReactionType());
          react.setTimestamp(newReact.getTimestamp());
          return repository.save(react);
        })
        .orElseGet(() -> {
          newReact.setReaction_ID(new ReactID(userId, postId));
          return repository.save(newReact);
        });
  }

  // Delete a react
  @DeleteMapping("/reacts/post/{postId}/user/{userId}")
  void deleteReact(@PathVariable Long postId, @PathVariable Long userId) {
    repository.deleteById(new ReactID(userId, postId));
  }
}
