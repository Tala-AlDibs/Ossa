
package com.project.project.React;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReactRepository extends JpaRepository<React, ReactID> {

}
