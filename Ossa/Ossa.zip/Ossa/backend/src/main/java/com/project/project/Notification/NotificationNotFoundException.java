package com.project.project.Notification;

class NotificationNotFoundException extends RuntimeException {

    NotificationNotFoundException(Long id) {
        super("Could not find Notification " + id);
    }
}
