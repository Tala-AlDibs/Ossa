package com.project.project.CommentLike;

class CommentLikeNotFoundException extends RuntimeException {

    CommentLikeNotFoundException(Long postId, Long userId) {
        super("Could not find Reaction for Post ID: " + postId + " and User ID: " + userId);
    }
}
