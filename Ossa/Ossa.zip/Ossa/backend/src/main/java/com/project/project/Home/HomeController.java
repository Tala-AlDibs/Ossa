package com.project.project.Home;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.project.project.User.*;

import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@SuppressWarnings("all")
@RestController
public class HomeController {

    @Autowired
    private HomeRepository homeRepository;

    // Get all homes (with links)
    @GetMapping("/homes")
    public CollectionModel<EntityModel<Home>> all() {

        List<EntityModel<Home>> homes = homeRepository.findAll().stream()
                .map(home -> EntityModel.of(home,
                        linkTo(methodOn(HomeController.class).one(home.getHome_ID())).withSelfRel(),
                        linkTo(methodOn(HomeController.class).all()).withRel("homes")))
                .collect(Collectors.toList());

        return CollectionModel.of(homes, linkTo(methodOn(HomeController.class).all()).withSelfRel());
    }

    // Get a single home by id
    @GetMapping(value = "/homes/{id}", produces = "application/hal+json")
    public EntityModel<Home> one(@PathVariable Long id) {

        Home home = homeRepository.findById(id) //
                .orElseThrow(() -> new HomeNotFoundException(id));

        return EntityModel.of(home, //
                linkTo(methodOn(HomeController.class).one(id)).withSelfRel(),
                linkTo(methodOn(HomeController.class).all()).withRel("homes"));
    }

    // Add a new home to the database
    @PostMapping("/homes")
    public ResponseEntity<Home> createHome(@RequestBody Home home) {
        Home savedHome = homeRepository.save(home);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedHome);
    }
}
