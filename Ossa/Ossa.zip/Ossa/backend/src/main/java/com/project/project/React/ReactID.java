package com.project.project.React;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Embeddable;
import lombok.Data;

@Data
@Embeddable
public class ReactID implements Serializable {

    private Long userId;
    private Long postId;

    // Default constructor (required by JPA)
    public ReactID() {
    }

    // Constructor with userId and postId parameters
    public ReactID(Long userId, Long postId) {
        this.userId = userId;
        this.postId = postId;
    }

    // Override equals and hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        ReactID likeId = (ReactID) o;
        return Objects.equals(userId, likeId.userId) && Objects.equals(postId, likeId.postId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, postId);
    }
}
