package com.project.project.BookMark;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
class BookMarkNotFoundAdvice {

    @ResponseBody
    @ExceptionHandler(BookMarkNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    String bookMarkNotFoundHandler(BookMarkNotFoundException ex) {
        return ex.getMessage();
    }
}
