package com.project.project.Home;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class HomeNotFoundAdvice {

    @ExceptionHandler(HomeNotFoundException.class)
    public ResponseEntity<String> handleHomeNotFoundException(HomeNotFoundException ex) {
        return ResponseEntity.notFound().build();
    }
}
