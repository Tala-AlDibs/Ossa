package com.project.project.Profile;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
class ProfileNotFoundAdvice {

  @ResponseBody
  @ExceptionHandler(ProfileNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  String ProfileNotFoundHandler(ProfileNotFoundException ex) {
    return ex.getMessage();
  }
}
