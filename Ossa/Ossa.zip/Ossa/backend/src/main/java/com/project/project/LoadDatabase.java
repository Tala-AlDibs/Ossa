// package com.project.project;

// import java.time.*;
// import java.util.*;

// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.CommandLineRunner;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.transaction.annotation.Transactional;

// import com.project.project.Home.*;
// import com.project.project.Messages.*;
// import com.project.project.Post.*;
// import com.project.project.Profile.*;
// import com.project.project.React.*;
// import com.project.project.User.*;
// import com.project.project.BookMark.*;
// import com.project.project.Comment.*;
// import com.project.project.Notification.*;

// @Configuration
// class LoadDatabase {

// @Autowired
// PasswordEncoder encoder;

// @Autowired
// ProfileRepository profileRepository;

// @Autowired
// HomeRepository homeRepository;

// @Autowired
// UserRepository userRepository;

// @Autowired
// NotificationRepository notificationRepository;

// @Autowired
// CommentRepository commentRepository;

// @Autowired
// BookMarkRepository bookmarkRepository;

// @Autowired
// PostRepository postRepository;

// @Autowired
// ReactRepository reactRepository;

// @Autowired
// MessageRepository messageRepository;

// private static final Logger log =
// LoggerFactory.getLogger(LoadDatabase.class);

// @Bean
// @Transactional
// CommandLineRunner initDatabase(UserRepository userRepository, PostRepository
// postRepository,
// ReactRepository reactRepository, MessageRepository messageRepository,
// NotificationRepository notificationRepository, CommentRepository
// commentRepository,
// BookMarkRepository bookMarkRepository) {

// // Create users
// User user = new User("john_doe123", "John", "Doe", "john123@example.com",
// encoder.encode("password"),
// Gender.MALE,
// LocalDate.of(1990, 1, 1), "Location", "2300827890");

// User userFriend = new User("jane_doe123", "Jane", "Doe",
// "jane123@example.com", encoder.encode("mypassword"),
// Gender.FEMALE,
// LocalDate.of(1990, 1, 1), "Location", "0123456789");

// // Create profiles
// Profile userProfile = new Profile("bio", "profile_picture.png", user);
// Profile userFriendProfile = new Profile("bio", "profile_picture.png",
// userFriend);

// // Save users and profiles
// userRepository.save(user);
// userRepository.save(userFriend);

// // Set friends
// user.setFriends(List.of(userFriend));
// userFriend.setFriends(List.of(user));

// // Set profiles
// user.setProfile(userProfile);
// userFriend.setProfile(userFriendProfile);

// // Create and save messages
// Message messageOne = new Message(user, userFriend, "Hello how are you?",
// LocalDateTime.now(),
// MessageStatus.delivered);
// Message messageTwo = new Message(userFriend, user, "I'm doing great!",
// LocalDateTime.now(), MessageStatus.seen);
// messageRepository.save(messageOne);
// messageRepository.save(messageTwo);

// // Set sent and received messages
// user.setSentMessages(List.of(messageOne));
// user.setReceivedMessages(List.of(messageTwo));
// userFriend.setSentMessages(List.of(messageTwo));
// userFriend.setReceivedMessages(List.of(messageOne));

// // Create and save a post
// Post post = new Post(PostType.TEXT, "Sample post content",
// LocalDateTime.now(), user, Privacy.PUBLIC);
// postRepository.save(post);

// // Create and save a react
// // ReactID reactId = new ReactID(user.getUser_ID(), post.getPost_ID());
// // React react = new React(reactId, ReactionType.HAHA, LocalDateTime.now(),
// user, post);
// // user.setReacts(List.of(react));
// // post.setReacts(List.of(react));
// // reactRepository.save(react);

// Notification commentNotification = new Notification(LocalDateTime.now(),"New
// comment", NotificationType.COMMENT);
// Notification reactNotification = new Notification(LocalDateTime.now(),"New
// react", NotificationType.REACT);
// notificationRepository.saveAll(List.of(commentNotification,
// reactNotification));

// // Set reacts

// // Set posts
// user.setPosts(List.of(post));

// // Create and save comments
// Comment comment = new Comment("This is a comment", LocalDateTime.now(), user,
// post);
// Comment reply = new Comment("This is a reply", LocalDateTime.now(), user,
// post);
// comment.setReplies(List.of(reply));
// reply.setParentComment(comment);
// post.setComments(List.of(comment, reply));
// commentRepository.save(comment);

// // Create and save bookmarks
// BookMark bookMark = new BookMark(LocalDateTime.now(), post, user);
// bookMarkRepository.save(bookMark);

// // Set bookmarks
// user.setBookMarks(List.of(bookMark));
// post.setBookMarks(List.of(bookMark));

// // Create home for the user
// Home home = new Home(user);
// user.setHome(home);
// homeRepository.save(home);

// return args -> {
// log.info("Preloaded a user");
// };
// }

// }
