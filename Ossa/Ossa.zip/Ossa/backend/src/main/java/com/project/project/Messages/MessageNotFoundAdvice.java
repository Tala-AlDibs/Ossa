package com.project.project.Messages;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class MessageNotFoundAdvice {
  @ResponseBody
  @ExceptionHandler(MessageNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  String MessageNotFoundHandler(MessageNotFoundException ex) {
    return ex.getMessage();
  }
}
