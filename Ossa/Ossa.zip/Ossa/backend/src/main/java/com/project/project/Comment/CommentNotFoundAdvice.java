package com.project.project.Comment;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
class CommentNotFoundAdvice {

  @ResponseBody
  @ExceptionHandler(CommentNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  String CommentNotFoundHandler(CommentNotFoundException ex) {
    return ex.getMessage();
  }
}
