package com.project.project.security.services;

import java.time.LocalDate;
import java.util.*;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.project.User.*;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserDetailsImpl implements UserDetails {
  private static final long serialVersionUID = 1L;

  protected Long user_ID;
  private String username;
  protected String first_name;
  protected String last_name;

  private String email;

  protected Gender gender;
  protected LocalDate date_of_birth;
  protected String location;
  protected String phone_number;

  @JsonIgnore
  private String password;

  private Collection<? extends GrantedAuthority> authorities;

  public UserDetailsImpl(Long id, String username, String first_name, String last_name,
      String email, String password, Gender gender,
      LocalDate date_of_birth, String location, String phone_number) {
    this.user_ID = id;
    this.username = username;
    this.email = email;
    this.password = password;
    this.date_of_birth = date_of_birth;
    this.first_name = first_name;
    this.last_name = last_name;
    this.gender = gender;
    this.location = location;
    this.phone_number = phone_number;
  }

  public static UserDetailsImpl build(User user) {

    return new UserDetailsImpl(
        user.getUser_ID(),
        user.getUsername(), user.getFirst_name(), user.getLast_name(),
        user.getEmail(),
        user.getPassword(), user.getGender(), user.getDate_of_birth(), user.getLocation(), user.getPhone_number());
  }

  public Long getId() {
    return user_ID;
  }

  public String getEmail() {
    return email;
  }

  @Override
  public String getPassword() {
    return password;
  }

  @Override
  public String getUsername() {
    return username;
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return true;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    UserDetailsImpl user = (UserDetailsImpl) o;
    return Objects.equals(user_ID, user.user_ID);
  }
}
