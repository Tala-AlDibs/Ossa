package com.project.project.controllers;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.project.project.Home.*;
import com.project.project.Profile.*;
import com.project.project.User.*;
import com.project.project.payload.request.*;
import com.project.project.payload.response.*;
import com.project.project.security.jwt.JwtUtils;
import com.project.project.security.services.UserDetailsImpl;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthController {
  @Autowired
  AuthenticationManager authenticationManager;

  @Autowired
  UserRepository userRepository;

  @Autowired
  PasswordEncoder encoder;

  @Autowired
  JwtUtils jwtUtils;

  @Autowired
  ProfileRepository profileRepository;

  @Autowired
  HomeRepository homeRepository;

  @PostMapping("/signin")
  public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

    Authentication authentication = authenticationManager.authenticate(
        new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

    SecurityContextHolder.getContext().setAuthentication(authentication);
    String jwt = jwtUtils.generateJwtToken(authentication);

    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

    return ResponseEntity.ok(new JwtResponse(jwt,
        userDetails.getId(),
        userDetails.getUsername(),
        userDetails.getEmail()));
  }

  @PostMapping("/signup")
  public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
    if (userRepository.existsByUsername(signUpRequest.getUsername())) {
      return ResponseEntity
          .badRequest()
          .body(new MessageResponse("Error: Username is already taken!"));
    }

    if (userRepository.existsByEmail(signUpRequest.getEmail())) {
      return ResponseEntity
          .badRequest()
          .body(new MessageResponse("Error: Email is already in use!"));
    }

    // Create new user's account
    User user = new User(signUpRequest.getUsername(),
        signUpRequest.getFirst_name(),
        signUpRequest.getLast_name(),
        signUpRequest.getEmail(),
        encoder.encode(signUpRequest.getPassword()),
        signUpRequest.getGender(),
        signUpRequest.getDate_of_birth(),
        signUpRequest.getLocation(),
        signUpRequest.getPhone_number());

    // Create profile for the user
    Profile profile = new Profile(signUpRequest.getProfile().getBio(),
        signUpRequest.getProfile().getProfile_picture(),
        user);
    userRepository.save(user);
    user.setProfile(profile);
    profileRepository.save(profile);

    // Create home for the user
    Home home = new Home(user);
    user.setHome(home);
    homeRepository.save(home);

    // Save user and associated entities

    return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
  }

}
