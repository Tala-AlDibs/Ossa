package com.project.project.BookMark;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.project.project.Post.*;
import com.project.project.User.*;

@RestController
public class BookMarkController {

    @Autowired
    private final BookMarkRepository repository;

    @Autowired
    private final PostRepository postRepository;

    @Autowired
    private final UserRepository userRepository;

    BookMarkController(BookMarkRepository repository, PostRepository postRepository, UserRepository userRepository) {
        this.repository = repository;
        this.postRepository = postRepository;
        this.userRepository = userRepository;
    }

    // Aggregate root
    // get all bookmarks
    @GetMapping("/bookmarks")
    CollectionModel<EntityModel<BookMark>> all() {

        List<EntityModel<BookMark>> bookmarks = repository.findAll().stream()
                .map(bookmark -> EntityModel.of(bookmark,
                        linkTo(methodOn(BookMarkController.class).one(bookmark.getBookMarkId())).withSelfRel(),
                        linkTo(methodOn(BookMarkController.class).all()).withRel("bookmarks")))
                .collect(Collectors.toList());

        return CollectionModel.of(bookmarks, linkTo(methodOn(BookMarkController.class).all()).withSelfRel());
    }

    // Create a new bookmark for a post by a user
    @PostMapping("/bookmarks/post/{postId}/user/{userId}")
    public ResponseEntity<BookMark> newBookmark(@RequestBody BookMark newBookmark, @PathVariable long postId,
            @PathVariable Long userId) {
        Optional<Post> optionalPost = postRepository.findById(postId);
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent() && optionalPost.isPresent()) {
            User user = optionalUser.get();
            newBookmark.setUser(user);
            Post post = optionalPost.get();
            newBookmark.setPost(post);

            newBookmark.setTimeStamp(LocalDateTime.now());

            BookMark savedBookMark = repository.save(newBookmark);
            post.addBookmark(newBookmark); // Add bookmark to the list
            user.addBookmark(newBookmark);// Add bookmark to the list
            return ResponseEntity.status(HttpStatus.CREATED).body(savedBookMark);
        } else {
            return null;
        }
    }

    // Single bookmark by id
    @GetMapping("/bookmarks/{id}")
    EntityModel<BookMark> one(@PathVariable Long id) {

        BookMark bookmark = repository.findById(id)
                .orElseThrow(() -> new BookMarkNotFoundException(id));

        return EntityModel.of(bookmark,
                linkTo(methodOn(BookMarkController.class).one(id)).withSelfRel(),
                linkTo(methodOn(BookMarkController.class).all()).withRel("bookmarks"));
    }

    // Get all bookmarks on a specific post
    @GetMapping("/bookmarks/post/{postId}")
    public CollectionModel<EntityModel<BookMark>> getBookmarksOnPost(@PathVariable long postId) {
        // Find bookmarks on a particular post
        List<EntityModel<BookMark>> bookmarks = repository.findAll().stream()
                .filter(bookmark -> bookmark.getPost().getPost_ID().equals(postId))
                .map(bookmark -> EntityModel.of(bookmark,
                        linkTo(methodOn(BookMarkController.class).one(bookmark.getBookMarkId())).withSelfRel(),
                        linkTo(methodOn(BookMarkController.class).all()).withRel("bookmarks")))
                .collect(Collectors.toList());

        return CollectionModel.of(bookmarks,
                linkTo(methodOn(BookMarkController.class).getBookmarksOnPost(postId)).withSelfRel());
    }

    // Get all bookmarks made by a specific user
    @GetMapping("/bookmarks/user/{userId}")
    public CollectionModel<EntityModel<BookMark>> getBookmarksByUser(@PathVariable long userId) {
        // Find bookmarks by a particular user
        List<EntityModel<BookMark>> bookmarks = repository.findAll().stream()
                .filter(bookmark -> bookmark.getUser().getUser_ID().equals(userId))
                .map(bookmark -> EntityModel.of(bookmark,
                        linkTo(methodOn(BookMarkController.class).one(bookmark.getBookMarkId())).withSelfRel(),
                        linkTo(methodOn(BookMarkController.class).all()).withRel("bookmarks")))
                .collect(Collectors.toList());

        return CollectionModel.of(bookmarks,
                linkTo(methodOn(BookMarkController.class).getBookmarksByUser(userId)).withSelfRel());
    }

    // Delete a bookmark
    @DeleteMapping("/bookmarks/{id}")
    ResponseEntity<?> deleteBookMark(@PathVariable Long id) {
        Optional<BookMark> optionalBookMark = repository.findById(id);
        if (optionalBookMark.isPresent()) {
            repository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}