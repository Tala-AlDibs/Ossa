package com.project.project.User;

import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

public class GenderDeserializer extends StdDeserializer<Gender> {
    public GenderDeserializer() {
        super(Gender.class);
    }

    @Override
    public Gender deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
        String genderStr = p.getText().toUpperCase(); // Convert to uppercase for case-insensitive comparison
        return Gender.valueOf(genderStr);
    }
}
