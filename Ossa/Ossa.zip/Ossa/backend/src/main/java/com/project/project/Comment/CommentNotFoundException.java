package com.project.project.Comment;

public class CommentNotFoundException extends RuntimeException {
  CommentNotFoundException(Long id) {
    super("Could not find Comment " + id);
  }
}
