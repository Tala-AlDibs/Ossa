package com.project.project.Post;

public enum PostType {
    TEXT, IMAGE, VIDEO, LINK, TEXTVIDEO, TEXTIMAGE, TEXTLINK
}
