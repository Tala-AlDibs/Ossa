package com.project.project.BookMark;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.*;

import com.project.project.Post.*;
import com.project.project.User.User;

@Entity
@Table
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BookMark {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookMarkId;
    private LocalDateTime timeStamp;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "post_ID", nullable = true)
    private Post post;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "user_ID", nullable = true)
    private User user;

    public BookMark(LocalDateTime timeStamp, Post post, User user) {
        this.timeStamp = timeStamp;
        this.post = post;
        this.user = user;

    }

    // Method to check if the bookmark is expired
    public boolean isExpired() {
        LocalDateTime now = LocalDateTime.now();
        return now.isAfter(timeStamp);
    }
}