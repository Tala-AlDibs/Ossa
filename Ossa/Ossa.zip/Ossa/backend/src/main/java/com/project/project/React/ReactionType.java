package com.project.project.React;

public enum ReactionType {
    LIKE, LOVE, HAHA, WOW, SAD, ANGRY
}
