package com.project.project.BookMark;

class BookMarkNotFoundException extends RuntimeException {

    BookMarkNotFoundException(Long id) {
        super("Could not find BookMark " + id);
    }
}
