package com.project.project.Comment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.validation.*;
import org.springframework.web.bind.annotation.*;

import com.project.project.Post.*;
import com.project.project.React.*;
import com.project.project.User.*;
import com.project.project.Notification.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@SuppressWarnings("all")
@RestController
public class CommentController {

    @Autowired
    private final CommentRepository commentRepository;

    @Autowired
    private final UserRepository userRepository;

    @Autowired
    private final PostRepository postRepository;

    @Autowired
    private final NotificationRepository notificationRepository;

    CommentController(CommentRepository commentRepository, UserRepository userRepository, PostRepository postRepository,
            NotificationRepository notificationRepository) {
        this.commentRepository = commentRepository;
        this.postRepository = postRepository;
        this.userRepository = userRepository;
        this.notificationRepository = notificationRepository;
    }

    // Aggregate root - Get all comments
    @GetMapping("/comments")
    public CollectionModel<EntityModel<Comment>> getAllComments() {
        List<EntityModel<Comment>> comments = commentRepository.findAll().stream()
                .map(comment -> EntityModel.of(comment,
                        linkTo(methodOn(CommentController.class).getCommentById(comment.getComment_ID()))
                                .withSelfRel()))
                .collect(Collectors.toList());

        return CollectionModel.of(comments, linkTo(methodOn(CommentController.class).getAllComments()).withSelfRel());
    }

    // Get a single comment by ID
    @GetMapping("/comments/{id}")
    public ResponseEntity<EntityModel<Comment>> getCommentById(@PathVariable Long id) {
        Optional<Comment> commentOptional = commentRepository.findById(id);
        return commentOptional.map(comment -> {
            return ResponseEntity.ok(EntityModel.of(comment,
                    linkTo(methodOn(CommentController.class).getCommentById(id)).withSelfRel(),
                    linkTo(methodOn(CommentController.class).getAllComments()).withRel("comments")));
        }).orElse(ResponseEntity.notFound().build());
    }

    // Create a new comment for a post by a user
    @PostMapping("/comments/post/{postId}/user/{userId}")
    public ResponseEntity<Comment> createComment(@RequestBody Comment comment, @PathVariable Long postId,
            @PathVariable Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        Optional<Post> optionalPost = postRepository.findById(postId);
        if (optionalUser.isPresent() && optionalPost.isPresent()) {
            User user = optionalUser.get();
            comment.setUser(user); // Set the user for the new react
            Post post = optionalPost.get();
            comment.setPost(post);
            comment.setDatePosted(LocalDateTime.now());
            Notification notification = new Notification(LocalDateTime.now(),
                    user.getUsername() + " commented on " + post.getUser().getUsername() + "'s post",
                    NotificationType.REACT);
            notificationRepository.save(notification);

            Comment savedComment = commentRepository.save(comment);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedComment);
        } else {
            return null;
        }
    }

    // Create a new reply for a comment by a user to an existing comment
    @PostMapping("/commentsReply/comment/{commentId}/user/{userId}")
    public ResponseEntity<?> createReply(@RequestBody Comment comment, @PathVariable Long commentId,
            @PathVariable Long userId, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            for (FieldError error : bindingResult.getFieldErrors()) {
                errors.put(error.getField(), error.getDefaultMessage());
            }
            return ResponseEntity.badRequest().body(errors);
        }

        Optional<User> optionalUser = userRepository.findById(userId);
        Optional<Comment> optionalComment = commentRepository.findById(commentId);

        if (optionalUser.isPresent() && optionalComment.isPresent()) {
            User user = optionalUser.get();
            Comment parentComment = optionalComment.get();

            // Set the user for the new reply
            comment.setUser(user);

            // Set the parent comment
            comment.setParentComment(parentComment);

            // Set the current date and time
            comment.setDatePosted(LocalDateTime.now());
            Long postId = parentComment.getPost().getPost_ID();
            comment.setPost(parentComment.getPost());

            Notification notification = new Notification(LocalDateTime.now(),
                    user.getUsername() + " replyed on a comment by " + parentComment.getPost().getUser().getUsername(),
                    NotificationType.REPLY);
            notificationRepository.save(notification);

            // Save the reply
            Comment savedComment = commentRepository.save(comment);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedComment);
        } else {
            return ResponseEntity.notFound().build(); // Return 404 Not Found if user or comment is not present
        }
    }

    // Get all replies to a comment
    @GetMapping("/commentsReply/comment/{commentId}")
    public ResponseEntity<?> getAllCommentsReplies(@PathVariable Long commentId) {
        Optional<Comment> optionalComment = commentRepository.findById(commentId);
        if (optionalComment.isPresent()) {
            Comment comment = optionalComment.get();
            List<Comment> replies = comment.getReplies();
            return ResponseEntity.ok(replies);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Get a single comment by ID
    @PutMapping("/comments/{id}")
    public ResponseEntity<Comment> updateComment(@PathVariable Long id, @RequestBody Comment updatedComment) {
        Optional<Comment> existingCommentOptional = commentRepository.findById(id);
        if (existingCommentOptional.isPresent()) {
            Comment existingComment = existingCommentOptional.get();
            existingComment.setContent(updatedComment.getContent());
            existingComment.setDatePosted(updatedComment.getDatePosted());
            return ResponseEntity.ok(commentRepository.save(existingComment));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete a comment by ID
    @DeleteMapping("/comments/{id}")
    public ResponseEntity<Void> deleteComment(@PathVariable Long id) {
        commentRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}