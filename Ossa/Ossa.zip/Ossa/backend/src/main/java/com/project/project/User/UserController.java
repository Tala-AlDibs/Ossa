package com.project.project.User;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.project.project.Notification.*;

@SuppressWarnings("all")
@RestController
public class UserController {

  @Autowired
  private final UserRepository repository;

  @Autowired
  private final NotificationRepository notificationRepository;

  UserController(UserRepository repository, NotificationRepository notificationRepository) {
    this.repository = repository;
    this.notificationRepository = notificationRepository;
  }

  // Aggregate root
  // tag::get-aggregate-root[]
  @GetMapping("/users")
  CollectionModel<EntityModel<User>> all() {

    List<EntityModel<User>> users = repository.findAll().stream()
        .map(user -> EntityModel.of(user,
            linkTo(methodOn(UserController.class).one(user.getUser_ID())).withSelfRel(),
            linkTo(methodOn(UserController.class).all()).withRel("Users")))
        .collect(Collectors.toList());

    return CollectionModel.of(users, linkTo(methodOn(UserController.class).all()).withSelfRel());
  }
  // end::get-aggregate-root[]

  // Post a new user
  @PostMapping("/users")
  public ResponseEntity<User> newUser(@RequestBody User newUser) {
    User savedUser = repository.save(newUser);
    return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);

  }

  // Create a friendship between two users
  @PostMapping("/users/{userId}/friendship/{friendId}")
  public ResponseEntity<String> createFriendship(@PathVariable Long userId, @PathVariable Long friendId) {
    Optional<User> optionalUser = repository.findById(userId);
    Optional<User> optionalFriend = repository.findById(friendId);

    if (optionalUser.isPresent() && optionalFriend.isPresent()) {
      User user = optionalUser.get();
      User friend = optionalFriend.get();

      // Check if the friendship already exists
      if (user.getFriends().contains(friend) || friend.getFriends().contains(user)) {
        return ResponseEntity.badRequest().body("Friendship already exists");
      }
      Notification notification = new Notification(LocalDateTime.now(),
          user.getUsername() + "User " + user.getUsername() + " and user " + friend.getUsername() + " became friends",
          NotificationType.FOLLOW);
      notificationRepository.save(notification);

      // Add friend to user's friend list
      user.getFriends().add(friend);
      repository.save(user);

      // Add user to friend's friend list
      friend.getFriends().add(user);
      repository.save(friend);

      return ResponseEntity.ok("Friendship created successfully");
    } else {
      return ResponseEntity.notFound().build(); // Return 404 Not Found if user or friend is not present
    }
  }

  // Delete a friendship between two users
  @DeleteMapping("/users/{userId}/friendship/{friendId}")
  public ResponseEntity<String> deleteFriendship(@PathVariable Long userId, @PathVariable Long friendId) {
    Optional<User> optionalUser = repository.findById(userId);
    Optional<User> optionalFriend = repository.findById(friendId);

    if (optionalUser.isPresent() && optionalFriend.isPresent()) {
      User user = optionalUser.get();
      User friend = optionalFriend.get();

      // Check if the friendship exists
      if (!user.getFriends().contains(friend) || !friend.getFriends().contains(user)) {
        return ResponseEntity.badRequest().body("Friendship does not exist");
      }

      // Remove friend from user's friend list
      user.getFriends().remove(friend);
      repository.save(user);

      // Remove user from friend's friend list
      friend.getFriends().remove(user);
      repository.save(friend);

      return ResponseEntity.ok("Friendship deleted successfully");
    } else {
      return ResponseEntity.notFound().build(); // Return 404 Not Found if user or friend is not present
    }
  }

  // Get all friends of a user
  @GetMapping("/users/{userId}/friends")
  public List<User> getAllFriends(@PathVariable Long userId) {
    Optional<User> optionalUser = repository.findById(userId);
    if (optionalUser.isPresent()) {
      User user = optionalUser.get();
      return user.getFriends();
    } else {
      return null;
    }
  }

  // Single item
  @GetMapping(value = "/users/{id}", produces = "application/hal+json")
  public EntityModel<User> one(@PathVariable Long id) {

    User user = repository.findById(id) //
        .orElseThrow(() -> new UserNotFoundException(id));

    return EntityModel.of(user, //
        linkTo(methodOn(UserController.class).one(id)).withSelfRel(),
        linkTo(methodOn(UserController.class).all()).withRel("Users"));
  }

  // Update a user
  @PutMapping("/users/{id}")
  public User replaceUser(@RequestBody User newUser, @PathVariable long id) {

    return repository.findById(id)
        .map(user -> {
          user.setUsername(newUser.getUsername());
          user.setFirst_name(newUser.getFirst_name());
          user.setLast_name(newUser.getLast_name());
          user.setEmail(newUser.getEmail());
          user.setPassword(newUser.getPassword());
          user.setGender(newUser.getGender());
          user.setDate_of_birth(newUser.getDate_of_birth());
          user.setLocation(newUser.getLocation());
          user.setPhone_number(newUser.getPhone_number());
          return repository.save(user);
        })
        .orElseGet(() -> {
          newUser.setUser_ID(id);
          return repository.save(newUser);
        });
  }

  // Delete a user and remove them from the friends list of all other users
  @DeleteMapping("/users/{id}")
  void deleteUser(@PathVariable Long id) {
    Optional<User> optionalUser = repository.findById(id);
    if (optionalUser.isPresent()) {
      User user = optionalUser.get();

      // Remove the user from the friends list of all other users
      for (User friend : user.getFriends()) {
        friend.getFriends().remove(user);
        repository.save(friend); // Save changes to the friend
      }

      repository.deleteById(id); // Delete the user
    }
  }
}
