package com.project.project.CommentLike;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.project.project.Comment.Comment;
import com.project.project.User.User;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "user_ID", "comment_ID" }))
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CommentLike {
    @EmbeddedId
    private CommentLikeID likeID;
    private LocalDateTime timestamp;

    @JsonIgnore
    @ManyToOne
    @MapsId("userId")
    @JoinColumn(name = "user_ID")
    private User user;

    @JsonIgnore
    @ManyToOne
    @MapsId("commentId")
    @JoinColumn(name = "comment_ID")
    private Comment comment;

    public CommentLike(LocalDateTime timestamp, User user, Comment comment) {
        this.timestamp = timestamp;
        this.user = user;
        this.comment = comment;
        this.likeID = new CommentLikeID(user.getUser_ID(), comment.getComment_ID());
    }

    // Add methods to access PostId and UserId from the composite key
    public Long getCommentId() {
        return likeID.getCommentId();
    }

    public Long getUserId() {
        return likeID.getUserId();
    }
}
