package com.project.project.Notification;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long notification_ID;
    private LocalDateTime timestamp;
    private String content;
    private NotificationType notificationType;

    public Notification(LocalDateTime timestamp, String content, NotificationType notificationType) {

        this.content = content;
        this.timestamp = timestamp;
        this.notificationType = notificationType;

    }

    public void displayNotification() {
        System.out.println("New notification at " + timestamp + ": " + content);
    }

    public String formatNotification() {
        return "New notification at " + timestamp + ": " + content;
    }

    public boolean isExpired() {
        LocalDateTime now = LocalDateTime.now();
        return now.isAfter(timestamp);
    }

}
