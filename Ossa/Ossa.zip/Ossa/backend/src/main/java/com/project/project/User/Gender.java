package com.project.project.User;

public enum Gender {
    FEMALE,
    MALE
}
