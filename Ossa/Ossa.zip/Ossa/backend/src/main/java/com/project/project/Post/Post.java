package com.project.project.Post;

import java.sql.Blob;
import java.time.LocalDateTime;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import com.project.project.BookMark.BookMark;
import com.project.project.Comment.Comment;
import com.project.project.Home.Home;
import com.project.project.Profile.Profile;
import com.project.project.React.React;
import com.project.project.User.User;

@Entity
@Table
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long post_ID;
    private PostType post_type;

    private String description;
    private Blob image;
    private LocalDateTime timestamp;
    private Privacy privacy;
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "user_ID", nullable = true)
    private User user;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "profile_ID", nullable = true)
    private Profile profile;

    @JsonIgnore
    @ManyToMany
    @JoinTable(name = "home_post", joinColumns = @JoinColumn(name = "post_id"), inverseJoinColumns = @JoinColumn(name = "home_id"))
    private List<Home> homes = new ArrayList<>();

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<BookMark> bookMarks = new ArrayList<>();

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<React> reacts = new ArrayList<>();

    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comment> comments = new ArrayList<>();

    public Post(PostType post_type, Blob image, String description, LocalDateTime timestamp, User user, Privacy privacy) {
        this.post_type = post_type;
        this.description = description;
        this.timestamp = timestamp;
        this.privacy = privacy;
        this.user = user;
        this.profile = user.getProfile();
        this.image = image;
        this.homes = new ArrayList<>();
        this.reacts = new ArrayList<>();
        this.comments = new ArrayList<>();
        this.bookMarks = new ArrayList<>();

    }

    public void addHome(Home home) {
        this.homes.add(home);
    }

    public void addBookmark (BookMark bookmark) {
        this.bookMarks.add(bookmark);
    }

}
