package com.project.project.Profile;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.project.Home.Home;
import com.project.project.Home.HomeController;
import com.project.project.User.*;

@SuppressWarnings("all")
@RestController
public class ProfileController {

  @Autowired
  private final ProfileRepository repository;

  @Autowired
  private final UserRepository userRepository;

  ProfileController(ProfileRepository repository, UserRepository userRepository) {
    this.repository = repository;
    this.userRepository = userRepository;
  }

  // Aggregate root
  // tag::get-aggregate-root[]
  @GetMapping("/profiles")
  public CollectionModel<EntityModel<Profile>> all() {

    List<EntityModel<Profile>> profiles = repository.findAll().stream()
        .map(profile -> EntityModel.of(profile,
            linkTo(methodOn(HomeController.class).one(profile.getProfile_ID())).withSelfRel(),
            linkTo(methodOn(HomeController.class).all()).withRel("profiles")))
        .collect(Collectors.toList());

    return CollectionModel.of(profiles, linkTo(methodOn(HomeController.class).all()).withSelfRel());
  }
  // end::get-aggregate-root[]

  @PostMapping("/profiles")
  public ResponseEntity<Profile> newProfile(@RequestBody Profile newProfile) {
    Profile savedProfile = repository.save(newProfile);
    return ResponseEntity.status(HttpStatus.CREATED).body(savedProfile);
  }

  // Single item
  @GetMapping("/profiles/{id}")
  EntityModel<Profile> one(@PathVariable Long id) {

    Profile profile = repository.findById(id) //
        .orElseThrow(() -> new ProfileNotFoundException(id));

    return EntityModel.of(profile, //
        linkTo(methodOn(ProfileController.class).one(id)).withSelfRel(),
        linkTo(methodOn(ProfileController.class).all()).withRel("Profiles"));
  }

  // Update a profile
  @PutMapping("/profiles/{id}")
  Profile replaceProfile(@RequestBody Profile newProfile, @PathVariable long id) {

    return repository.findById(id)
        .map(profile -> {
          profile.setBio(newProfile.getBio());
          profile.setFirst_name(newProfile.getFirst_name());
          profile.setLast_name(newProfile.getLast_name());
          profile.setEmail(newProfile.getEmail());
          profile.setPassword(newProfile.getPassword());
          profile.setProfile_picture(newProfile.getProfile_picture());
          profile.setGender(newProfile.getGender());
          profile.setDate_of_birth(newProfile.getDate_of_birth());
          profile.setLocation(newProfile.getLocation());
          profile.setPhone_number(newProfile.getPhone_number());
          return repository.save(profile);
        })
        .orElseGet(() -> {
          newProfile.setProfile_ID(id);
          return repository.save(newProfile);
        });
  }
}
